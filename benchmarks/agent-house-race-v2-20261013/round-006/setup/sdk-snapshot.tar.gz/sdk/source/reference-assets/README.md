# `@aperture-engine/reference-assets`

Versioned reference corpus payloads for `@aperture-engine/cli`.

The package also ships `dist/studio-neutral.hdr`, Aperture's MIT-licensed,
procedurally generated neutral studio environment for deterministic offline
model previews. See [ASSETS.md](./ASSETS.md) for provenance and licensing.

This package is not an application runtime dependency. It owns the producer
workflow that generates precomputed reference embeddings and source snippets for
the CLI/MCP reference tools and docs-site browser search. Published package
versions expose the compressed `dist/data.tgz` payload, compact
`dist/browser-search.json` browser-search payload, and `dist/manifest.json`.

The matching embedding model files are not bundled in this package. During
`aperture reference warmup`, `@aperture-engine/cli` downloads this data payload
from the package CDN and then downloads the pinned local Transformers.js model
files recorded in the CLI model contract.

The browser-search payload keeps the same source chunks but quantizes normalized
embedding vectors to int8 so static docs pages can perform similarity search
without loading the full producer JSON.

Useful producer commands:

```sh
pnpm --filter @aperture-engine/reference-assets run build:payload
pnpm --filter @aperture-engine/reference-assets run ingest
pnpm --filter @aperture-engine/reference-assets run build
```

Workspace ingestion reuses vectors from the checksum-verified local reference
cache when the complete pinned model contract and exact embedding text match.
It embeds changed inputs, drops removed chunks, and rebuilds source content,
metadata, line numbers, entries and archives from the current workspace. An
unchanged corpus does not initialize the native embedding model. Missing,
corrupt or incompatible cache data is regenerated. Producer logs report reused
and generated chunk counts.

Corpus, package data and package dist are prepared in sibling staging
directories before publication, so generation failures retain their previous
published bytes. Updating the cache never rewrites a retained benchmark SDK or
historical evidence snapshot.

Workspace corpus builds use an exclusive per-root lock and fail immediately
when another build owns it. Retry after that build finishes. If its process has
ended without cleanup, remove the lock path reported by the error before
retrying. Publication uses sibling directory renames; concurrent readers may
briefly observe a missing path during replacement.

For local development, build the payload and point the CLI at the generated
package dist directory:

```sh
pnpm --filter @aperture-engine/reference-assets run build:payload
pnpm exec aperture reference warmup --from packages/reference-assets/dist
```

Public users normally run:

```sh
pnpm exec aperture reference warmup
```
