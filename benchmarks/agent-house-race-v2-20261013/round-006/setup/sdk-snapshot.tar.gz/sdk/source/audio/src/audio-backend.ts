/**
 * The Web Audio seam.
 *
 * Everything the audio engine does to make sound flows through an
 * {@link AudioBackend}. In the browser it is backed by a real
 * {@link AudioContext}; in tests it is backed by a deterministic fake
 * (see `./test-support.ts`). This mirrors aperture's render-backend boundary:
 * realization is swappable, the logic above it is not. Keeping the surface
 * this narrow is what lets the voice/mixer logic be unit-tested with zero Web
 * Audio and asserted as PCM only in the browser e2e layer.
 */
export interface AudioBackend {
  /** Monotonic audio clock in seconds (`AudioContext.currentTime`). */
  readonly currentTime: number;
  readonly state: AudioContextState;
  readonly sampleRate: number;
  /** Processing block latency in seconds (`AudioContext.baseLatency`). */
  readonly baseLatency: number;
  /** Estimated output latency in seconds — used for latency compensation. */
  readonly outputLatency: number;
  /** The single Web Audio listener (one per context). */
  readonly listener: AudioListener;
  /** Terminal node the master chain connects into. */
  readonly destination: AudioNode;

  resume(): Promise<void>;
  suspend(): Promise<void>;
  close(): Promise<void>;

  /** Decode encoded bytes (mp3/ogg/wav/…) into a playable buffer. */
  decode(bytes: ArrayBuffer): Promise<AudioBuffer>;

  createGain(): GainNode;
  createSource(): AudioBufferSourceNode;
  createMediaSource(element: HTMLMediaElement): MediaElementAudioSourceNode;
  /** A streamed source (long music) backed by a media element — no decode. */
  createStreamingSource(url: string): StreamingSource;
  createPanner(): PannerNode;
  createBiquad(): BiquadFilterNode;
  createConvolver(): ConvolverNode;
  createAnalyser(): AnalyserNode;
  createCompressor(): DynamicsCompressorNode;
  /**
   * Try to build an AudioWorklet brickwall limiter node; resolves null when the
   * worklet API / cross-origin isolation is unavailable (degrade to compressor).
   */
  createWorkletLimiter(): Promise<AudioNode | null>;
}

/** Inline AudioWorklet brickwall limiter — hard-clamps samples to ±0.99. */
const BRICKWALL_PROCESSOR = `
registerProcessor("aperture-brickwall-limiter", class extends AudioWorkletProcessor {
  process(inputs, outputs) {
    const input = inputs[0];
    const output = outputs[0];
    if (!output) return true;
    for (let c = 0; c < output.length; c++) {
      const oc = output[c];
      // When the upstream is mono (e.g. the accessibility mono-downmix), input
      // has one channel; fall back to channel 0 so every output channel carries
      // the signal instead of writing silence to the right channel.
      const ic = input ? input[c] || input[0] : undefined;
      if (!oc) continue;
      for (let i = 0; i < oc.length; i++) {
        const s = ic ? ic[i] : 0;
        oc[i] = s > 0.99 ? 0.99 : s < -0.99 ? -0.99 : s;
      }
    }
    return true;
  }
});
`;

/** A streamed media-element source: its graph node plus transport controls. */
export interface StreamingSource {
  readonly node: AudioNode;
  play(): void;
  stop(): void;
  setLoop(loop: boolean): void;
}

export interface WebAudioBackendOptions {
  /** Provide an existing context (e.g. shared with another subsystem). */
  readonly context?: AudioContext;
  readonly latencyHint?: AudioContextLatencyCategory | number;
  readonly sampleRate?: number;
}

interface WebkitAudioWindow {
  webkitAudioContext?: typeof AudioContext;
}

/**
 * Wrap a real {@link AudioContext}. Only callable on the main thread of a
 * browser; the worker side of the engine never imports this.
 */
export function createWebAudioBackend(
  options: WebAudioBackendOptions = {},
): AudioBackend {
  const context = options.context ?? createBrowserContext(options);
  // A given processor name can only be registered once per context; track it so
  // re-enabling the worklet limiter on a shared/reused context is idempotent
  // instead of throwing "already registered" and silently degrading.
  let workletModuleAdded = false;

  return {
    get currentTime(): number {
      return context.currentTime;
    },
    get state(): AudioContextState {
      return context.state;
    },
    get sampleRate(): number {
      return context.sampleRate;
    },
    get baseLatency(): number {
      return context.baseLatency;
    },
    get outputLatency(): number {
      return context.outputLatency;
    },
    get listener(): AudioListener {
      return context.listener;
    },
    get destination(): AudioNode {
      return context.destination;
    },
    resume: () => context.resume(),
    suspend: () => context.suspend(),
    close: () => context.close(),
    // slice(0) so decodeAudioData (which detaches its input) cannot strand the
    // caller's encoded bytes — the same defensive copy three.js's AudioLoader makes.
    decode: (bytes) => context.decodeAudioData(bytes.slice(0)),
    createGain: () => context.createGain(),
    createSource: () => context.createBufferSource(),
    createMediaSource: (element) => context.createMediaElementSource(element),
    createStreamingSource: (url) => {
      const element = new Audio(url);
      element.crossOrigin = "anonymous";
      const node = context.createMediaElementSource(element);
      return {
        node,
        play: () => {
          void element.play();
        },
        stop: () => {
          // stop() is terminal here — the voice discards the stream right after —
          // so release the network/media resource, not just pause it. Clearing
          // `src` + load() lets the browser tear down the underlying HTMLMediaElement.
          element.pause();
          try {
            element.currentTime = 0;
          } catch {
            // Not seekable yet — ignore.
          }
          element.removeAttribute("src");
          element.load();
        },
        setLoop: (loop) => {
          element.loop = loop;
        },
      };
    },
    createPanner: () => context.createPanner(),
    createBiquad: () => context.createBiquadFilter(),
    createConvolver: () => context.createConvolver(),
    createAnalyser: () => context.createAnalyser(),
    createCompressor: () => context.createDynamicsCompressor(),
    createWorkletLimiter: async () => {
      const worklet = (
        context as unknown as {
          audioWorklet?: { addModule(url: string): Promise<void> };
        }
      ).audioWorklet;
      if (worklet === undefined || typeof AudioWorkletNode === "undefined") {
        return null;
      }
      try {
        if (!workletModuleAdded) {
          const blob = new Blob([BRICKWALL_PROCESSOR], {
            type: "text/javascript",
          });
          const url = URL.createObjectURL(blob);
          await worklet.addModule(url);
          URL.revokeObjectURL(url);
          workletModuleAdded = true;
        }
        return new AudioWorkletNode(
          context as unknown as BaseAudioContext,
          "aperture-brickwall-limiter",
        );
      } catch {
        return null;
      }
    },
  };
}

function createBrowserContext(options: WebAudioBackendOptions): AudioContext {
  const Ctor =
    typeof AudioContext !== "undefined"
      ? AudioContext
      : (globalThis as WebkitAudioWindow).webkitAudioContext;

  if (Ctor === undefined) {
    throw new Error(
      "Web Audio API is unavailable: no AudioContext in this environment.",
    );
  }

  const contextOptions: AudioContextOptions = {};

  if (options.latencyHint !== undefined) {
    contextOptions.latencyHint = options.latencyHint;
  }
  if (options.sampleRate !== undefined) {
    contextOptions.sampleRate = options.sampleRate;
  }

  return new Ctor(contextOptions);
}
