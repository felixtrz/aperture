// In-process devtools routing for the warm headless server: the same ECS and
// input tool contracts exposed over MCP, but driven against an in-process
// createApertureHeadlessRunner instead of a browser/worker. No worker or
// message-port machinery is pulled in.
export {
  createGeneratedEntityToolBridge,
  type GeneratedEntityToolBridge,
  type GeneratedComponentMutationAffordance,
  type GeneratedComponentSchema,
  type GeneratedComponentSchemaReport,
} from "./devtools/entities.js";
export {
  createAssetSummary,
  inspectGltfAsset,
  type GltfAssetInspectionReport,
} from "./devtools/assets.js";
export { callCameraTool, type CameraToolState } from "./devtools/camera.js";
export type { CameraFramingReport } from "./devtools/camera-framing.js";
export { callInputDevtoolsTool } from "./devtools/input.js";
export type { GeneratedDevtoolsToolResult } from "./devtools/types.js";
