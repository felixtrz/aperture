import type { SimulationWorker } from "@aperture-engine/runtime";
import type { ApertureConfig } from "../config.js";
import {
  createGeneratedInputEventMessage,
  type ApertureGeneratedInputEvent,
} from "../input.js";
import type { ApertureGeneratedPointerName } from "../input/state.js";
import type { GeneratedBrowserAppStatus } from "./status.js";

export const APERTURE_GENERATED_VIRTUAL_INPUT_EVENT =
  "aperture.generated.virtualAction" as const;

export interface ApertureVirtualActionInput {
  readonly source?: string;
  readonly pressed?: boolean;
  readonly value?: boolean | number;
  readonly x?: number;
  readonly y?: number;
}

export function dispatchApertureInputAction(
  action: string,
  input: boolean | number | ApertureVirtualActionInput = true,
  scope: EventTarget = globalThis as unknown as EventTarget,
): void {
  const detail =
    typeof input === "boolean"
      ? { action, pressed: input }
      : typeof input === "number"
        ? { action, value: input }
        : { action, ...input };

  scope.dispatchEvent(
    new CustomEvent(APERTURE_GENERATED_VIRTUAL_INPUT_EVENT, {
      detail,
    }),
  );
}

export function installGeneratedInputForwarding(
  canvas: HTMLCanvasElement,
  worker: SimulationWorker,
  status: GeneratedBrowserAppStatus,
  config: ApertureConfig,
  options: {
    readonly signal?: AbortSignal;
    readonly pollGamepads?: boolean;
  } = {},
): void {
  const listenerOptions =
    options.signal === undefined ? undefined : { signal: options.signal };
  if (!canvas.hasAttribute("tabindex")) {
    canvas.tabIndex = 0;
  }

  canvas.addEventListener(
    "pointermove",
    (event) => {
      forwardInput(worker, status, {
        kind: "pointer",
        pointer: "primary",
        position: pointerPosition(canvas, event),
      });
    },
    listenerOptions,
  );

  canvas.addEventListener(
    "pointerdown",
    (event) => {
      const pointer = pointerNameFromButton(event.button);
      if (pointer === null) {
        return;
      }

      canvas.focus();
      safelySetPointerCapture(canvas, event.pointerId);
      forwardInput(worker, status, {
        kind: "pointer",
        pointer,
        position: pointerPosition(canvas, event),
        pressed: true,
      });
    },
    listenerOptions,
  );

  canvas.addEventListener(
    "pointerup",
    (event) => {
      const pointer = pointerNameFromButton(event.button);
      if (pointer === null) {
        return;
      }

      safelyReleasePointerCapture(canvas, event.pointerId);
      forwardInput(worker, status, {
        kind: "pointer",
        pointer,
        position: pointerPosition(canvas, event),
        pressed: false,
      });
    },
    listenerOptions,
  );

  const releasePointer = (event: PointerEvent): void => {
    const position = pointerPosition(canvas, event);
    for (const pointer of GENERATED_POINTER_BUTTONS) {
      forwardInput(worker, status, {
        kind: "pointer",
        pointer,
        position,
        pressed: false,
      });
    }
  };

  canvas.addEventListener("pointercancel", releasePointer, listenerOptions);
  canvas.addEventListener("pointerleave", releasePointer, listenerOptions);
  canvas.addEventListener(
    "lostpointercapture",
    releasePointer,
    listenerOptions,
  );

  canvas.addEventListener(
    "wheel",
    (event) => {
      // The wheel drives in-app scroll/zoom (worker-side UiScroll mapping),
      // so keep the page from scrolling underneath the canvas.
      event.preventDefault();
      forwardInput(worker, status, {
        kind: "wheel",
        deltaX: wheelDeltaPixels(event.deltaX, event.deltaMode),
        deltaY: wheelDeltaPixels(event.deltaY, event.deltaMode),
      });
    },
    { passive: false, ...listenerOptions },
  );

  window.addEventListener(
    "keydown",
    (event) => {
      if (event.repeat) {
        return;
      }

      forwardInput(worker, status, {
        kind: "keyboard",
        key: event.code || event.key,
        pressed: true,
      });
    },
    listenerOptions,
  );

  window.addEventListener(
    "keyup",
    (event) => {
      forwardInput(worker, status, {
        kind: "keyboard",
        key: event.code || event.key,
        pressed: false,
      });
    },
    listenerOptions,
  );

  window.addEventListener(
    APERTURE_GENERATED_VIRTUAL_INPUT_EVENT,
    (event) => {
      const inputEvent = virtualActionEventFromDetail(
        (event as CustomEvent).detail,
      );

      if (inputEvent === null) {
        return;
      }

      forwardInput(worker, status, inputEvent);
    },
    listenerOptions,
  );

  window.addEventListener(
    "blur",
    () => {
      forwardInputReset(worker, status, "window-blur");
    },
    listenerOptions,
  );

  document.addEventListener(
    "visibilitychange",
    () => {
      if (document.visibilityState === "hidden") {
        forwardInputReset(worker, status, "document-hidden");
      }
    },
    listenerOptions,
  );

  if (options.pollGamepads !== false)
    installGeneratedGamepadPolling(worker, status, config, options.signal);
}

function safelySetPointerCapture(
  canvas: HTMLCanvasElement,
  pointerId: number,
): void {
  try {
    canvas.setPointerCapture?.(pointerId);
  } catch {
    // Pointer capture can be rejected for synthetic, already-released, or
    // pointer-lock-transition events. Input forwarding must still continue.
  }
}

function safelyReleasePointerCapture(
  canvas: HTMLCanvasElement,
  pointerId: number,
): void {
  try {
    canvas.releasePointerCapture?.(pointerId);
  } catch {
    // Release is best-effort for the same browser paths as capture.
  }
}

const GENERATED_POINTER_BUTTONS = [
  "primary",
  "secondary",
  "middle",
] as const satisfies readonly ApertureGeneratedPointerName[];

function pointerNameFromButton(
  button: number,
): ApertureGeneratedPointerName | null {
  switch (button) {
    case 0:
      return "primary";
    case 1:
      return "middle";
    case 2:
      return "secondary";
    default:
      return null;
  }
}

function forwardInput(
  worker: SimulationWorker,
  status: GeneratedBrowserAppStatus,
  event: ApertureGeneratedInputEvent,
): void {
  worker.postMessage(createGeneratedInputEventMessage(event));
  status.forwardedInputEvents += 1;
  status.lastInputEvent = event;
}

function forwardInputReset(
  worker: SimulationWorker,
  status: GeneratedBrowserAppStatus,
  reason: string,
): void {
  status.lastInputReset = reason;
  forwardInput(worker, status, {
    kind: "reset",
    reason,
  });
}

function installGeneratedGamepadPolling(
  worker: SimulationWorker,
  status: GeneratedBrowserAppStatus,
  config: ApertureConfig,
  signal?: AbortSignal,
): void {
  if (typeof navigator.getGamepads !== "function") {
    return;
  }

  let lastConnected = 0;
  let polling = false;
  let disposed = false;
  let frame: number | null = null;
  signal?.addEventListener(
    "abort",
    () => {
      disposed = true;
      if (frame !== null && typeof cancelAnimationFrame === "function")
        cancelAnimationFrame(frame);
      window.removeEventListener("gamepadconnected", startPolling);
    },
    { once: true },
  );
  const shouldListen = configUsesGamepads(config);

  const startPolling = (): void => {
    if (polling || disposed) {
      return;
    }

    polling = true;
    frame = requestAnimationFrame(poll);
  };
  const poll = (): void => {
    frame = null;
    if (disposed) return;
    const gamepads = browserGamepadSnapshots();
    const shouldForward = gamepads.length > 0 || lastConnected > 0;
    status.connectedGamepads = gamepads.length;

    if (shouldForward) {
      forwardInput(worker, status, {
        kind: "gamepad",
        replace: true,
        gamepads,
      });
      status.forwardedInputFrames += 1;
    }

    lastConnected = gamepads.length;
    if (gamepads.length === 0) {
      polling = false;
      armGamepadConnectedListener();
      return;
    }

    frame = requestAnimationFrame(poll);
  };
  const armGamepadConnectedListener = (): void => {
    window.addEventListener("gamepadconnected", startPolling, {
      once: true,
    });
  };

  if (!shouldListen) {
    return;
  }

  if (browserGamepadSnapshots().length > 0) {
    startPolling();
  } else {
    armGamepadConnectedListener();
  }
}

function browserGamepadSnapshots(): NonNullable<
  Extract<ApertureGeneratedInputEvent, { readonly kind: "gamepad" }>["gamepads"]
> {
  return [...navigator.getGamepads()]
    .filter((gamepad): gamepad is Gamepad => gamepad !== null)
    .map((gamepad) => ({
      index: gamepad.index,
      id: gamepad.id,
      mapping: gamepad.mapping,
      connected: gamepad.connected,
      buttons: gamepad.buttons.map((button) => ({
        pressed: button.pressed,
        touched: button.touched,
        value: button.value,
      })),
      axes: [...gamepad.axes],
    }));
}

function virtualActionEventFromDetail(
  detail: unknown,
): ApertureGeneratedInputEvent | null {
  if (!isRecord(detail)) {
    return null;
  }

  const action = stringFromValue(detail["action"]);
  if (action === undefined) {
    return null;
  }

  const x = numberFromValue(detail["x"]);
  const y = numberFromValue(detail["y"]);

  return {
    kind: "virtualAction",
    action,
    source: stringFromValue(detail["source"]) ?? "browser",
    ...(typeof detail["pressed"] === "boolean"
      ? { pressed: detail["pressed"] }
      : {}),
    ...(typeof detail["value"] === "boolean" ||
    typeof detail["value"] === "number"
      ? { value: detail["value"] }
      : {}),
    ...(x === undefined ? {} : { x }),
    ...(y === undefined ? {} : { y }),
  };
}

function configUsesGamepads(config: ApertureConfig): boolean {
  for (const descriptor of Object.values(config.input?.actions ?? {})) {
    const bindings = Array.isArray(descriptor)
      ? descriptor
      : "bindings" in descriptor
        ? descriptor.bindings
        : [];

    if (
      bindings.some(
        (binding) =>
          "gamepad" in binding ||
          ("kind" in binding && binding.kind.startsWith("gamepad")),
      )
    ) {
      return true;
    }
  }

  return false;
}

// Browsers report wheel travel in pixels, lines, or pages depending on the
// device/platform (WheelEvent.deltaMode). The worker only ever sees pixel
// deltas, so normalize the unit here — the sample values stay raw otherwise.
const WHEEL_LINE_DELTA_PIXELS = 16;
const WHEEL_PAGE_DELTA_PIXELS = 800;

function wheelDeltaPixels(delta: number, deltaMode: number): number {
  if (!Number.isFinite(delta)) {
    return 0;
  }

  if (deltaMode === WheelEvent.DOM_DELTA_LINE) {
    return delta * WHEEL_LINE_DELTA_PIXELS;
  }

  if (deltaMode === WheelEvent.DOM_DELTA_PAGE) {
    return delta * WHEEL_PAGE_DELTA_PIXELS;
  }

  return delta;
}

function pointerPosition(
  canvas: HTMLCanvasElement,
  event: PointerEvent,
): readonly [number, number] {
  const rect = canvas.getBoundingClientRect();
  const x = rect.width <= 0 ? 0 : (event.clientX - rect.left) / rect.width;
  const y = rect.height <= 0 ? 0 : (event.clientY - rect.top) / rect.height;

  return [clamp01(x), clamp01(y)];
}

function clamp01(value: number): number {
  return Math.min(1, Math.max(0, value));
}

function stringFromValue(value: unknown): string | undefined {
  return typeof value === "string" && value.length > 0 ? value : undefined;
}

function numberFromValue(value: unknown): number | undefined {
  return Number.isFinite(value) ? (value as number) : undefined;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}
