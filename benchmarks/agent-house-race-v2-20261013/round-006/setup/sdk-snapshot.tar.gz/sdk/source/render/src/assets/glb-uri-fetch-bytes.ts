import type {
  LoadGlbFromUriDiagnostic,
  LoadGlbFromUriFetchResponse,
} from "./glb-uri-loader.js";
import {
  diagnosticForFetchInput,
  fetchFailedDiagnostic,
  httpErrorDiagnostic,
  readFailedDiagnostic,
} from "./glb-uri-fetch-byte-diagnostics.js";
import type {
  FetchBytesInput,
  FetchBytesResult,
} from "./glb-uri-fetch-byte-types.js";

export type {
  FetchBytesInput,
  FetchBytesResult,
} from "./glb-uri-fetch-byte-types.js";
export { fetchIndexFields } from "./glb-uri-fetch-byte-diagnostics.js";

export async function fetchBytes(
  input: FetchBytesInput,
): Promise<FetchBytesResult> {
  if (input.cache !== undefined) {
    return fetchBytesWithCache(input);
  }

  return fetchBytesWithoutCache(input);
}

class CachedFetchDiagnosticError extends Error {
  constructor(readonly diagnostic: LoadGlbFromUriDiagnostic) {
    super(diagnostic.message);
  }
}

async function fetchBytesWithCache(
  input: FetchBytesInput,
): Promise<FetchBytesResult> {
  const cache = input.cache;

  if (cache === undefined) {
    return fetchBytesWithoutCache(input);
  }

  let cached = cache.bytes.get(input.url);

  if (cached === undefined) {
    cached = fetchBytesWithoutCache(input).then((result) => {
      if (!result.ok) {
        cache.bytes.delete(input.url);
        throw new CachedFetchDiagnosticError(result.diagnostic);
      }

      return result.bytes;
    });
    cache.bytes.set(input.url, cached);
  }

  try {
    return { ok: true, bytes: await cached };
  } catch (error) {
    if (error instanceof CachedFetchDiagnosticError) {
      return {
        ok: false,
        diagnostic: diagnosticForFetchInput(error.diagnostic, input),
      };
    }

    return {
      ok: false,
      diagnostic: fetchFailedDiagnostic(input, error),
    };
  }
}

async function fetchBytesWithoutCache(
  input: FetchBytesInput,
): Promise<FetchBytesResult> {
  let response: LoadGlbFromUriFetchResponse;

  try {
    response = await input.fetcher(input.url);
  } catch (error) {
    return {
      ok: false,
      diagnostic: fetchFailedDiagnostic(input, error),
    };
  }

  if (!response.ok) {
    return {
      ok: false,
      diagnostic: httpErrorDiagnostic(input, response),
    };
  }

  try {
    return { ok: true, bytes: await response.arrayBuffer() };
  } catch (error) {
    return {
      ok: false,
      diagnostic: readFailedDiagnostic(input, error),
    };
  }
}
