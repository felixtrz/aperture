import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { assertStepArguments } from "../tools/control-arguments.js";
import { assertInputInjection } from "../tools/input-schemas.js";
import {
  createApertureHeadlessEcsDigest,
  createApertureHeadlessRunner,
  createApertureHeadlessStatusDigest,
  createApertureRenderSnapshotDigest,
  createApertureSessionSnapshot,
  assertSupportedSessionSnapshot,
  type ApertureHeadlessStatus,
  type ApertureHeadlessRunner,
  type ApertureSessionSnapshot,
  type ApertureSessionRestoreReport,
} from "@aperture-engine/app/headless";
import {
  callCameraTool,
  callInputDevtoolsTool,
  createAssetSummary,
  createGeneratedEntityToolBridge,
  inspectGltfAsset,
  type CameraToolState,
  type GeneratedDevtoolsToolResult,
  type GeneratedEntityToolBridge,
} from "@aperture-engine/app/headless-tools";
import { createApertureDevtoolsRequest } from "@aperture-engine/app/commands";
import type { ApertureGeneratedInputEvent } from "@aperture-engine/app/input";
import type { ApertureDeterminismDiagnosticsMode } from "@aperture-engine/app/systems";
import { errorToApertureDiagnostic } from "@aperture-engine/app/diagnostics";
import {
  defineApertureConfig,
  type ApertureConfig,
} from "@aperture-engine/app/config";
import {
  assertApertureBootstrapAllowed,
  getApertureCleanupFailures,
  preflightApertureApp,
  type ApertureSystemModule,
} from "@aperture-engine/app/advanced";
import { getApertureEntitySummary } from "@aperture-engine/app/entity-lookup";
import {
  invertMat4,
  raycast,
  transformPoint,
  vec3Normalize,
  vec3Subtract,
  vec3Tuple,
  type EcsWorld,
  type RaycastableBounds,
  type RaycastHit,
} from "@aperture-engine/simulation";
import type { MeshDrawPacket, RenderSnapshot } from "@aperture-engine/render";
import { ApertureCliError } from "../errors.js";
import { loadApertureHeadlessApp } from "./config-loader.js";
import {
  createNodeApertureAssetLoader,
  type NodeAssetLoaderMode,
} from "./node-asset-loader.js";
import {
  assertInjectActionsDriveButtons,
  createApertureHeadlessInjectEvents,
  parseApertureHeadlessInjectStep,
} from "./inject.js";
import {
  createApertureSnapshotBundle,
  renderBundleTargetFromRenderDefaults,
} from "./bundle.js";
import { syncAutoAspectCameras } from "./auto-aspect.js";
import {
  disposeHeadlessRunner,
  headlessDisposeFailureMessage,
} from "./dispose-runner.js";

export const DEFAULT_HEADLESS_DELTA = 1 / 60;
export const DEFAULT_HEADLESS_RENDER_WIDTH = 960;
export const DEFAULT_HEADLESS_RENDER_HEIGHT = 640;
/** Frame cap for `untilQuiescent` stepping (agent-stumble: brittle waits). */
export const DEFAULT_HEADLESS_QUIESCENT_MAX_FRAMES = 240;
/** Default number of hits a viewport pick returns, nearest first. */
export const DEFAULT_HEADLESS_PICK_MAX_HITS = 10;

export interface HeadlessSessionControllerOptions {
  readonly config: ApertureConfig;
  readonly systems: readonly ApertureSystemModule[];
  readonly seed: number;
  readonly assetMode: NodeAssetLoaderMode;
  readonly root: string;
  readonly publicDir: string;
  readonly decoderAssetsDir?: string;
  readonly allowHttpAssets: boolean;
  readonly determinism: ApertureDeterminismDiagnosticsMode;
  /** Session render target; drives autoAspect cameras. Defaults to 960x640. */
  readonly renderWidth?: number;
  readonly renderHeight?: number;
  readonly log?: (entry: HeadlessSessionLogEntry) => void;
  /** Internal fresh-realm boot restoration; never constructs a second world. */
  readonly initialSnapshot?: ApertureSessionSnapshot;
  readonly validateSnapshot?: (
    snapshot: ApertureSessionSnapshot,
    runner: ApertureHeadlessRunner,
  ) => void;
}

export interface HeadlessSessionControllerFromConfigOptions extends Omit<
  HeadlessSessionControllerOptions,
  "config" | "systems"
> {
  readonly configFile: string;
}

export interface HeadlessSessionLogEntry {
  readonly time: string;
  readonly level: "debug" | "info" | "warn" | "error";
  readonly source: string;
  readonly code?: string;
  readonly message: string;
  readonly data?: unknown;
}

export interface HeadlessStepInput {
  readonly delta?: number;
  readonly time?: number;
  readonly frames?: number;
  readonly digest?: boolean;
  /**
   * When false, advance the simulation without running render extraction each
   * frame (finding F18). Counts in the result then reflect the last extracted
   * frame; call extract()/bundle to refresh render data. Defaults to true.
   */
  readonly extract?: boolean;
  /**
   * Step frame-by-frame until the session is quiescent — the extracted render
   * digest stops changing, the command bus has drained, and no assets are
   * still loading — or `maxFrames` is reached (agent-stumble: brittle waits).
   * Replaces hand-rolled waitForRuntimeQuiescence polling with a bounded,
   * machine-checkable wait. Overrides `frames` and always extracts; the step
   * result then carries a `quiescence` report. Hitting `maxFrames` without
   * settling is a legitimate outcome (a continuously-animating sim never
   * settles), reported as `quiescent: false` — never an error.
   */
  readonly untilQuiescent?: boolean;
  /** Frame cap for `untilQuiescent` (default 240). */
  readonly maxFrames?: number;
}

/** Result payload attached to step results when `untilQuiescent` is set. */
export interface HeadlessStepQuiescenceReport {
  readonly quiescent: boolean;
  readonly reason: "digest-stable" | "max-frames";
  readonly framesStepped: number;
  readonly pendingCommands: number;
  readonly pendingAssets: number;
}

export interface HeadlessPickInput {
  readonly x: number;
  readonly y: number;
  /**
   * "pixels" (default) addresses the session render size with a top-left
   * origin — the same space frame_capture renders; "ndc" is -1..1 with +Y up.
   */
  readonly coordinateSpace?: "ndc" | "pixels";
  /** View to pick through; defaults to the primary (first) extracted view. */
  readonly viewId?: number;
  /**
   * Optional extra layer filter. A draw is considered when it overlaps the
   * view's layerMask AND (when given) this mask.
   */
  readonly layerMask?: number;
  /** Maximum hits returned, nearest first (default 10). */
  readonly maxHits?: number;
}

export interface HeadlessPickHit {
  /** Stable id in the same { index, generation } shape ecs_find_entities reports. */
  readonly entity: { readonly index: number; readonly generation: number };
  readonly key?: string;
  readonly name?: string;
  readonly renderId: number;
  readonly distance: number;
  readonly point: readonly [number, number, number];
  readonly boundsIndex: number;
}

export type HeadlessPickResult =
  | {
      readonly ok: true;
      readonly method: "bounds-ray";
      readonly frame: number;
      readonly ray: {
        readonly origin: readonly [number, number, number];
        readonly direction: readonly [number, number, number];
      };
      readonly hits: readonly HeadlessPickHit[];
      readonly view: {
        readonly viewId: number;
        readonly viewport: readonly [number, number, number, number];
      };
    }
  | {
      readonly ok: false;
      readonly diagnostics: readonly {
        readonly code: string;
        readonly message: string;
      }[];
    };

export interface HeadlessExtractInput {
  readonly frame?: number;
  readonly digest?: boolean;
}

export interface HeadlessBundleInput {
  readonly out: string;
  readonly width?: number;
  readonly height?: number;
  readonly digest?: boolean;
  readonly createdBy?: string;
}

export interface HeadlessResetInput {
  readonly seed?: number;
}

export interface HeadlessToolInput {
  readonly name: string;
  readonly arguments?: unknown;
}

export type HeadlessSessionLifecycle =
  | "ready"
  | "replacing"
  | "failed"
  | "disposed";

export interface HeadlessSessionController {
  readonly lifecycle: HeadlessSessionLifecycle;
  readonly runner: ApertureHeadlessRunner;
  readonly seed: number;
  readonly initialRestoreReport: unknown;
  compactStatus(): unknown;
  status(input?: { readonly digest?: boolean }): unknown;
  step(input?: HeadlessStepInput): unknown;
  extract(input?: HeadlessExtractInput): {
    readonly snapshot: RenderSnapshot;
    readonly result: unknown;
  };
  inject(input: unknown): GeneratedDevtoolsToolResult;
  pick(input: HeadlessPickInput): HeadlessPickResult;
  dispatchCommand(input: {
    readonly channel: string;
    readonly payload?: unknown;
  }): unknown;
  reset(input?: HeadlessResetInput): Promise<unknown>;
  callTool(input: HeadlessToolInput): GeneratedDevtoolsToolResult;
  createBundle(input: HeadlessBundleInput): Promise<unknown>;
  saveSessionSnapshot(input: { readonly out: string }): Promise<unknown>;
  restoreSessionSnapshot(input: {
    readonly snapshot: ApertureSessionSnapshot;
  }): Promise<unknown>;
  determinismReport(): unknown;
  dispose(): Promise<void>;
}

interface MutableControllerState {
  runner: ApertureHeadlessRunner;
  entityTools: GeneratedEntityToolBridge;
  savedCameraStates: Map<string, CameraToolState>;
  seed: number;
}

export async function createHeadlessSessionControllerFromConfig(
  options: HeadlessSessionControllerFromConfigOptions,
): Promise<HeadlessSessionController> {
  const loaded = await loadApertureHeadlessApp({
    configFile: options.configFile,
    root: options.root,
  });

  for (const diagnostic of loaded.diagnostics) {
    options.log?.({
      time: new Date().toISOString(),
      level: "warn",
      source: "config-loader",
      code: diagnostic.code,
      message: diagnostic.message,
      data: diagnostic,
    });
  }

  return createHeadlessSessionController({
    ...options,
    config: loaded.config,
    systems: loaded.systems,
  });
}

/** Validate without constructing a world or changing process-global component storage. */
export function preflightHeadlessSessionController(
  options: Pick<HeadlessSessionControllerOptions, "config" | "systems">,
): void {
  assertApertureBootstrapAllowed();
  const config = defineApertureConfig(options.config);
  if (config.mode !== "headless")
    throw new ApertureCliError(
      "aperture.headless.invalidMode",
      "A headless session requires mode: 'headless'.",
    );
  preflightApertureApp(options);
}

const MAX_SESSION_LOG_ENTRIES = 200;

export async function createHeadlessSessionController(
  options: HeadlessSessionControllerOptions,
): Promise<HeadlessSessionController> {
  // Session-local log ring so `logs_read` works against the warm headless
  // session itself (#71), not only through the MCP manager's buffer.
  const logEntries: HeadlessSessionLogEntry[] = [];
  const loggedDiagnostics = new Set<string>();

  function log(entry: HeadlessSessionLogEntry): void {
    logEntries.push(entry);
    if (logEntries.length > MAX_SESSION_LOG_ENTRIES) {
      logEntries.shift();
    }
    options.log?.(entry);
  }

  const sessionRenderWidth = positiveIntegerValue(
    options.renderWidth,
    DEFAULT_HEADLESS_RENDER_WIDTH,
  );
  const sessionRenderHeight = positiveIntegerValue(
    options.renderHeight,
    DEFAULT_HEADLESS_RENDER_HEIGHT,
  );

  let current: MutableControllerState | null = null;
  let lifecycle: HeadlessSessionLifecycle = "replacing";
  let currentSeed = options.seed;
  let lastFailure: unknown;
  let closing = false;
  let pendingReplacement: Promise<
    ApertureSessionRestoreReport | undefined
  > | null = null;

  function requireActive(): MutableControllerState {
    if (closing || lifecycle !== "ready" || current === null) {
      throw new ApertureCliError(
        "aperture.headless.sessionUnavailable",
        `Headless session is ${closing ? "disposed" : lifecycle}. ${getApertureCleanupFailures().length > 0 ? "Cleanup failed; restart the process." : "Retry reset or restore after the current operation finishes."}`,
      );
    }
    return current;
  }

  function unavailableStatus(): unknown {
    const blocked = getApertureCleanupFailures();
    return {
      mode: "headless",
      running: false,
      lifecycle: closing ? "disposed" : lifecycle,
      seed: currentSeed,
      retryable: !closing && lifecycle === "failed" && blocked.length === 0,
      cleanupBlocked: blocked.length > 0,
      diagnostics: [
        ...(lastFailure === undefined
          ? []
          : [
              {
                code:
                  lastFailure instanceof ApertureCliError
                    ? lastFailure.code
                    : "aperture.headless.sessionUnavailable",
                severity: "error",
                message:
                  lastFailure instanceof Error
                    ? lastFailure.message
                    : String(lastFailure),
              },
            ]),
        ...blocked.map((error) => ({
          code: "aperture.headless.runnerDisposeFailed",
          severity: "error",
          message: headlessDisposeFailureMessage(error),
        })),
      ],
    };
  }

  function recordLifecycleFailure(error: unknown): void {
    for (const failure of [error, ...getApertureCleanupFailures()]) {
      const message = headlessDisposeFailureMessage(failure);
      const key = `lifecycle:${message}`;
      if (loggedDiagnostics.has(key)) continue;
      loggedDiagnostics.add(key);
      try {
        log({
          time: new Date().toISOString(),
          level: "error",
          source: "session-controller",
          code:
            failure === error
              ? "aperture.headless.sessionUnavailable"
              : "aperture.headless.runnerDisposeFailed",
          message,
        });
      } catch {
        /* The ring retains the error even if the external logger throws. */
      }
    }
  }

  function preflight(snapshot?: ApertureSessionSnapshot): void {
    assertApertureBootstrapAllowed();
    if (closing)
      throw new ApertureCliError(
        "aperture.headless.sessionUnavailable",
        "The headless session has been disposed.",
      );
    if (pendingReplacement !== null)
      throw new ApertureCliError(
        "aperture.headless.sessionUnavailable",
        "A headless replacement is already in progress.",
      );
    preflightHeadlessSessionController(options);
    if (snapshot !== undefined) assertSupportedSessionSnapshot(snapshot);
  }

  async function initialize(
    seed: number,
    snapshot?: ApertureSessionSnapshot,
  ): Promise<ApertureSessionRestoreReport | undefined> {
    let runner: ApertureHeadlessRunner | undefined;
    try {
      runner = await bootRunner(options, seed);
      if (snapshot !== undefined) options.validateSnapshot?.(snapshot, runner);
      const restore =
        snapshot === undefined
          ? undefined
          : runner.restoreSessionSnapshot(snapshot);
      if (restore?.ok === false) {
        await disposeRunner(runner, log);
        current = null;
        lifecycle = "failed";
        lastFailure = new ApertureCliError(
          "aperture.headless.restoreIncomplete",
          "Session snapshot restoration was incomplete. The candidate was disposed; inspect the restore report before retrying reset or restore.",
        );
        recordLifecycleFailure(lastFailure);
        return restore;
      }
      const next: MutableControllerState = {
        runner,
        entityTools: createGeneratedEntityToolBridge(runner.app.lowLevel.world),
        savedCameraStates: new Map(),
        seed,
      };
      syncAutoAspectCameras(
        runner.app.lowLevel.world,
        sessionRenderWidth,
        sessionRenderHeight,
      );
      logPlaceholders(log, runner);
      current = next;
      currentSeed = seed;
      lifecycle = "ready";
      lastFailure = undefined;
      return restore;
    } catch (error: unknown) {
      if (runner !== undefined) await disposeRunner(runner, log);
      current = null;
      lifecycle = "failed";
      lastFailure = error;
      recordLifecycleFailure(error);
      throw error;
    }
  }

  // Initial boot has no predecessor, but owns its runner through all setup.
  preflight(options.initialSnapshot);
  const initialRestore = await initialize(
    options.seed,
    options.initialSnapshot,
  );

  function syncAspect(
    width = sessionRenderWidth,
    height = sessionRenderHeight,
  ): void {
    syncAutoAspectCameras(
      requireActive().runner.app.lowLevel.world,
      width,
      height,
    );
  }

  function replace(
    seed: number,
    snapshot?: ApertureSessionSnapshot,
  ): Promise<ApertureSessionRestoreReport | undefined> {
    // Pure validation keeps the old session usable when no world was created.
    preflight(snapshot);
    const previous = current;
    current = null;
    lifecycle = "replacing";
    pendingReplacement = (async () => {
      try {
        if (previous !== null) await disposeRunner(previous.runner, log);
        // A rejected disposer may have left old callbacks alive. Never create
        // another world's process-global component storage in that case.
        assertApertureBootstrapAllowed();
        return await initialize(seed, snapshot);
      } catch (error: unknown) {
        lifecycle = "failed";
        lastFailure = error;
        recordLifecycleFailure(error);
        throw error;
      } finally {
        pendingReplacement = null;
      }
    })();
    return pendingReplacement;
  }

  function compactStatus(): unknown {
    if (closing || lifecycle !== "ready") return unavailableStatus();
    const status = requireActive().runner.getStatus();
    return {
      mode: status.mode,
      nextFrame: status.nextFrame,
      placeholders:
        requireActive().runner.app.lowLevel.assets.createManifestReport()
          .placeholders,
      assetMode: options.assetMode,
      allowHttpAssets: options.allowHttpAssets,
      determinism: options.determinism,
      seed: requireActive().seed,
    };
  }

  function status(input: { readonly digest?: boolean } = {}): unknown {
    if (closing || lifecycle !== "ready") return unavailableStatus();
    const current = requireActive().runner.getStatus();
    // The active seed is a session-level concept the runner status does not
    // carry; surface it here so get-status reports the seed instead of leaving
    // it undefined (finding F7).
    return withOptionalDigests(
      { ...current, seed: requireActive().seed },
      input,
      current,
    );
  }

  function step(input: HeadlessStepInput = {}): unknown {
    assertStepArguments(input);
    if (input.untilQuiescent === true) {
      return stepUntilQuiescent(input);
    }
    syncAspect();
    const frames = positiveIntegerValue(input.frames, 1);
    const delta = finiteNumber(input.delta, DEFAULT_HEADLESS_DELTA);
    const baseTime = finiteNumber(
      input.time,
      requireActive().runner.getStatus().nextFrame * delta,
    );
    const shouldExtract = input.extract !== false;

    let status: ApertureHeadlessStatus;
    let snapshot: RenderSnapshot | undefined;

    if (shouldExtract) {
      for (let index = 0; index < frames; index += 1) {
        requireActive().runner.stepWithoutExtract(
          delta,
          baseTime + index * delta,
        );
      }
      syncAspect();
      const report = requireActive().runner.extract(
        Math.max(0, requireActive().runner.getStatus().nextFrame - 1),
      );
      status = report.status;
      snapshot = report.snapshot;
    } else {
      // Step-without-extract escape hatch (F18): skip the up-front and
      // per-frame extraction entirely.
      let stepStatus = requireActive().runner.getStatus();
      for (let index = 0; index < frames; index += 1) {
        stepStatus = requireActive().runner.stepWithoutExtract(
          delta,
          baseTime + index * delta,
        ).status;
      }
      status = stepStatus;
    }

    // Surface determinism violations in every step result (not only in
    // get-status), and honor `--determinism error` in the warm loop by failing
    // the step — matching the one-shot's hard gate (finding F11).
    const violations = determinismViolations(status.diagnostics);
    if (violations.length > 0 && options.determinism === "error") {
      throw new ApertureCliError(
        "aperture.headless.determinismViolation",
        `Headless determinism policy failed with ${violations.length} nondeterministic global use(s): ${describeDeterminismViolations(
          violations,
        )}`,
      );
    }

    return withOptionalDigests(
      {
        nextFrame: status.nextFrame,
        counts: status.lastSnapshot?.counts ?? null,
        extracted: shouldExtract,
        ...(violations.length === 0
          ? {}
          : { determinism: { mode: options.determinism, violations } }),
      },
      input,
      status,
      snapshot,
    );
  }

  // Quiescence-aware stepping (agent-stumble: brittle waits). Agents used to
  // hand-roll waitForRuntimeQuiescence helpers around waitForFunction polling
  // in the browser; headlessly the same question — "has the sim settled?" —
  // is machine-checkable. A frame is quiescent when, after stepping it:
  //   1. the extracted render snapshot digest equals the previous frame's,
  //   2. the command bus has no queued commands left to drain, and
  //   3. no assets are still loading per the manifest report.
  function stepUntilQuiescent(input: HeadlessStepInput): unknown {
    const delta = finiteNumber(input.delta, DEFAULT_HEADLESS_DELTA);
    const baseTime = finiteNumber(
      input.time,
      requireActive().runner.getStatus().nextFrame * delta,
    );
    const maxFrames = positiveIntegerValue(
      input.maxFrames,
      DEFAULT_HEADLESS_QUIESCENT_MAX_FRAMES,
    );

    syncAspect();
    // Baseline digest of the pre-step extraction, so an already-settled sim
    // is recognized after a single confirming frame.
    let extraction = requireActive().runner.extract(
      requireActive().runner.getStatus().nextFrame,
    );
    let previousDigest = quiescenceDigestHash(extraction.snapshot);

    let framesStepped = 0;
    let quiescent = false;
    let pendingCommands = countQueuedCommands();
    let pendingAssets = countLoadingAssets();

    while (framesStepped < maxFrames && !quiescent) {
      requireActive().runner.stepWithoutExtract(
        delta,
        baseTime + framesStepped * delta,
      );
      framesStepped += 1;
      syncAspect();
      extraction = requireActive().runner.extract(
        Math.max(0, requireActive().runner.getStatus().nextFrame - 1),
      );

      // Honor the determinism policy on every frame of the wait loop, exactly
      // like a plain step (F11).
      const frameViolations = determinismViolations(
        extraction.status.diagnostics,
      );
      if (frameViolations.length > 0 && options.determinism === "error") {
        throw new ApertureCliError(
          "aperture.headless.determinismViolation",
          `Headless determinism policy failed with ${frameViolations.length} nondeterministic global use(s): ${describeDeterminismViolations(
            frameViolations,
          )}`,
        );
      }

      const digest = quiescenceDigestHash(extraction.snapshot);
      pendingCommands = countQueuedCommands();
      pendingAssets = countLoadingAssets();
      quiescent =
        digest === previousDigest &&
        pendingCommands === 0 &&
        pendingAssets === 0;
      previousDigest = digest;
    }

    const status = extraction.status;
    const violations = determinismViolations(status.diagnostics);
    // Hitting maxFrames without settling is NOT an error: a continuously
    // animating sim legitimately never settles; the caller decides.
    const quiescence: HeadlessStepQuiescenceReport = {
      quiescent,
      reason: quiescent ? "digest-stable" : "max-frames",
      framesStepped,
      pendingCommands,
      pendingAssets,
    };

    return withOptionalDigests(
      {
        nextFrame: status.nextFrame,
        counts: status.lastSnapshot?.counts ?? null,
        extracted: true,
        quiescence,
        ...(violations.length === 0
          ? {}
          : { determinism: { mode: options.determinism, violations } }),
      },
      input,
      status,
      extraction.snapshot,
    );
  }

  function countQueuedCommands(): number {
    return Object.values(
      requireActive().runner.app.context.commands.summary().queuedByChannel,
    ).reduce((total, count) => total + count, 0);
  }

  // The asset manifest report has no dedicated "pending" field; `byStatus`
  // buckets every registered asset, and in-flight loads sit in the "loading"
  // bucket. "registered" entries are declared-but-not-requested and may
  // legitimately stay that way forever, so they do not block quiescence.
  function countLoadingAssets(): number {
    return requireActive().runner.app.lowLevel.assets.createManifestReport()
      .byStatus.loading;
  }

  function extract(input: HeadlessExtractInput = {}): {
    readonly snapshot: RenderSnapshot;
    readonly result: unknown;
  } {
    syncAspect();
    const report = requireActive().runner.extract(
      finiteNumber(input.frame, requireActive().runner.getStatus().nextFrame),
    );
    return {
      snapshot: report.snapshot,
      result: withOptionalDigests(
        {
          frame: report.snapshot.frame,
          counts: report.status.lastSnapshot?.counts ?? null,
        },
        input,
        report.status,
        report.snapshot,
      ),
    };
  }

  // Deterministic viewport pick (agent-stumble: pixel-hunt picking). A
  // transform-gizmo test was deleted after screenshot pixel-hunting failed;
  // "what is at viewport x,y" is answerable from machine-checkable state
  // instead: unproject (x, y) through the view's recorded view-projection
  // matrix and intersect the ray against each mesh draw's world-space bounds.
  // This is deliberately bounds-level CPU picking — a hit means "this
  // entity's bounds are under the cursor", which is what editor controls and
  // placement checks need — not pixel-perfect GPU/triangle picking.
  function pick(input: HeadlessPickInput): HeadlessPickResult {
    if (!Number.isFinite(input.x) || !Number.isFinite(input.y)) {
      throw new ApertureCliError(
        "aperture.headless.invalidPick",
        "The pick requires finite numeric 'x' and 'y' coordinates.",
      );
    }

    const { snapshot } = extract({});
    const view =
      input.viewId === undefined
        ? snapshot.views[0]
        : snapshot.views.find((candidate) => candidate.viewId === input.viewId);

    if (view === undefined) {
      return {
        ok: false,
        diagnostics: [
          snapshot.views.length === 0
            ? {
                code: "aperture.headless.pickNoView",
                message:
                  "The extracted render snapshot has no views to pick through. Spawn a camera (or enable render.defaultCamera) and step a frame first.",
              }
            : {
                code: "aperture.headless.pickViewNotFound",
                message: `No extracted view has viewId ${input.viewId}. Available viewIds: ${snapshot.views
                  .map((candidate) => candidate.viewId)
                  .join(", ")}.`,
              },
        ],
      };
    }

    // ViewPacket viewports are normalized rects resolved against the render
    // target — here the session render size, the same size frame_capture
    // renders and autoAspect cameras follow.
    const viewport: readonly [number, number, number, number] = [
      vecComponent(view.viewport, 0),
      vecComponent(view.viewport, 1),
      vecComponent(view.viewport, 2),
      vecComponent(view.viewport, 3),
    ];

    // Mirror the renderer's rectangle semantics: it clamps the normalized
    // viewport AND scissor to integer pixel rects against the render target
    // and only shades fragments inside their intersection. A pick outside the
    // rendered rectangle must report "nothing rendered here", not bounds hits
    // for clipped-away pixels.
    const viewportRect = resolvePickRect(
      view.viewport,
      sessionRenderWidth,
      sessionRenderHeight,
    );
    const scissorRect = resolvePickRect(
      view.scissor,
      sessionRenderWidth,
      sessionRenderHeight,
    );
    const effectiveRect = intersectPickRects(viewportRect, scissorRect);
    if (viewportRect === null || effectiveRect === null) {
      return {
        ok: false,
        diagnostics: [
          {
            code: "aperture.headless.pickDegenerateViewport",
            message: `View ${view.viewId} renders no pixels: viewport [${viewport.join(", ")}] and scissor clamp to an empty rectangle on the ${sessionRenderWidth}x${sessionRenderHeight} render target.`,
          },
        ],
      };
    }

    let ndcX: number;
    let ndcY: number;
    let pixelX: number;
    let pixelY: number;
    if ((input.coordinateSpace ?? "pixels") === "ndc") {
      ndcX = input.x;
      ndcY = input.y;
      // The GPU viewport transform maps NDC across the CLAMPED viewport rect.
      pixelX = viewportRect.left + ((ndcX + 1) / 2) * viewportRect.width;
      pixelY = viewportRect.top + ((1 - ndcY) / 2) * viewportRect.height;
    } else {
      pixelX = input.x;
      pixelY = input.y;
      // Pixel origin is top-left; NDC +Y is up.
      ndcX = ((pixelX - viewportRect.left) / viewportRect.width) * 2 - 1;
      ndcY = 1 - ((pixelY - viewportRect.top) / viewportRect.height) * 2;
    }

    if (
      pixelX < effectiveRect.left ||
      pixelX >= effectiveRect.right ||
      pixelY < effectiveRect.top ||
      pixelY >= effectiveRect.bottom
    ) {
      return {
        ok: false,
        diagnostics: [
          {
            code: "aperture.headless.pickOutsideView",
            message: `Pick (${input.x}, ${input.y}) falls outside view ${view.viewId}'s rendered rectangle [${effectiveRect.left}, ${effectiveRect.top}, ${effectiveRect.right}, ${effectiveRect.bottom}) (viewport ∩ scissor on the ${sessionRenderWidth}x${sessionRenderHeight} render target); nothing is rendered at that point.`,
          },
        ],
      };
    }

    const matrixOffset = view.viewProjectionMatrixOffset;
    const viewProjection = snapshot.viewMatrices.subarray(
      matrixOffset,
      matrixOffset + 16,
    );
    const inverseViewProjection =
      viewProjection.length === 16 ? invertMat4(viewProjection) : null;
    if (inverseViewProjection === null) {
      return {
        ok: false,
        diagnostics: [
          {
            code: "aperture.headless.pickSingularViewProjection",
            message: `View ${view.viewId} has no invertible view-projection matrix; a pick ray cannot be reconstructed.`,
          },
        ],
      };
    }

    // Unproject on the WebGPU [0, 1] clip-depth range: z=0 is the near plane
    // (ray origin); z=0.5 samples a point inside the frustum for the
    // direction (z=1 would hit the w=0 singularity of infinite-far
    // projections).
    const origin = transformPoint(inverseViewProjection, [ndcX, ndcY, 0]);
    const interior = transformPoint(inverseViewProjection, [ndcX, ndcY, 0.5]);
    const direction = vec3Normalize(vec3Subtract(interior, origin));

    // A draw is pickable when its layers overlap the view's layerMask AND,
    // when given, the caller's extra filter.
    const candidates: RaycastableBounds<MeshDrawPacket>[] = [];
    for (const draw of snapshot.meshDraws) {
      if ((draw.layerMask & view.layerMask) === 0) {
        continue;
      }
      if (
        input.layerMask !== undefined &&
        (draw.layerMask & input.layerMask) === 0
      ) {
        continue;
      }
      const bounds = snapshot.bounds[draw.boundsIndex];
      if (bounds === undefined) {
        continue;
      }
      candidates.push({
        entity: draw,
        worldAabb: bounds.worldAabb,
        worldSphere: bounds.worldSphere,
      });
    }

    const maxHits = positiveIntegerValue(
      input.maxHits,
      DEFAULT_HEADLESS_PICK_MAX_HITS,
    );
    const hits = raycast(candidates, origin, direction)
      .slice(0, maxHits)
      .map((hit) =>
        pickHitFromRaycast(requireActive().runner.app.lowLevel.world, hit),
      );

    return {
      ok: true,
      method: "bounds-ray",
      frame: snapshot.frame,
      ray: {
        origin: vec3Tuple(origin),
        direction: vec3Tuple(direction),
      },
      hits,
      view: { viewId: view.viewId, viewport },
    };
  }

  function inject(input: unknown): GeneratedDevtoolsToolResult {
    const stepInput = parseApertureHeadlessInjectStep(input);
    if (stepInput.actions !== undefined) {
      // Fail loudly on a non-button action instead of silently dropping the
      // event downstream (#69).
      assertInjectActionsDriveButtons(
        requireActive().runner.app.context.input,
        stepInput.actions,
      );
    }
    requireActive().runner.enqueueInputBatch(
      createApertureHeadlessInjectEvents(stepInput),
      requireActive().runner.getStatus().nextFrame,
    );
    return { ok: true, result: { injected: true } };
  }

  function dispatchCommand(input: {
    readonly channel: string;
    readonly payload?: unknown;
  }): unknown {
    // Post an app command onto the shared command bus. Systems drain it via
    // context.commands.drain(channel) on the next step. Without this verb the
    // command channel — driven by the browser host/HUD in the browser — could
    // not be exercised headlessly (finding F16).
    if (typeof input.channel !== "string" || input.channel.length === 0) {
      throw new ApertureCliError(
        "aperture.headless.invalidCommand",
        "The command dispatch requires a non-empty 'channel'.",
      );
    }
    // Some MCP clients serialize structured tool arguments to JSON strings, so
    // an object payload arrives here as '"[{\"op\":...}]"'. App-side decoders
    // expect structured values and would reject (or silently drop) the string,
    // making the dispatch report ok while the command no-ops. Coerce
    // JSON-object/array-shaped strings back to structured values at this
    // boundary and surface the coercion as a diagnostic; leave every other
    // string payload untouched (a plain string is a legitimate command).
    const coerced = coerceJsonStringPayload(input.payload);
    requireActive().runner.app.context.commands.queue(
      input.channel,
      coerced.payload,
    );
    return {
      dispatched: true,
      channel: input.channel,
      ...(coerced.wasCoerced
        ? {
            payloadCoerced: true,
            diagnostics: [
              {
                code: "aperture.headless.commandPayloadCoerced",
                message:
                  "The command payload arrived as a JSON string and was parsed into a structured value before enqueue. Send structured payloads to avoid the coercion.",
              },
            ],
          }
        : {}),
      summary: requireActive().runner.app.context.commands.summary(),
    };
  }

  async function reset(input: HeadlessResetInput = {}): Promise<unknown> {
    await replace(finiteNumber(input.seed, options.seed));
    return { reset: true, status: compactStatus() };
  }

  async function createBundle(input: HeadlessBundleInput): Promise<unknown> {
    const current = requireActive().runner.getStatus();
    const frame =
      current.lastSnapshot === null
        ? current.nextFrame
        : current.lastSnapshot.frame;
    // Re-extract with autoAspect cameras matched to THIS bundle's render
    // target so the recorded projection fits the requested output size.
    syncAspect(
      positiveIntegerValue(input.width, DEFAULT_HEADLESS_RENDER_WIDTH),
      positiveIntegerValue(input.height, DEFAULT_HEADLESS_RENDER_HEIGHT),
    );
    const report = requireActive().runner.extract(frame);
    const bundle = createApertureSnapshotBundle({
      snapshot: report.snapshot,
      assets: requireActive().runner.app.lowLevel.assets,
      options: {
        createdBy: input.createdBy ?? "aperture headless",
        renderTarget: {
          // Carry the app's render/post config (tonemap/exposure/bloom/msaa)
          // so on-demand renders reproduce the final look (#73).
          ...renderBundleTargetFromRenderDefaults(options.config.render),
          width: positiveIntegerValue(
            input.width,
            DEFAULT_HEADLESS_RENDER_WIDTH,
          ),
          height: positiveIntegerValue(
            input.height,
            DEFAULT_HEADLESS_RENDER_HEIGHT,
          ),
        },
        allowPlaceholders: options.assetMode !== "strict",
      },
    });

    await mkdir(path.dirname(input.out), { recursive: true });
    await writeFile(input.out, `${JSON.stringify(bundle)}\n`, "utf8");
    return withOptionalDigests(
      {
        path: input.out,
        frame: bundle.frame,
        assetProvenance: bundle.assetProvenance,
        renderTarget: bundle.renderTarget,
        bundle,
      },
      input,
      report.status,
      report.snapshot,
    );
  }

  async function saveSessionSnapshot(input: {
    readonly out: string;
  }): Promise<unknown> {
    const snapshot = createApertureSessionSnapshot(requireActive().runner);
    await mkdir(path.dirname(input.out), { recursive: true });
    await writeFile(input.out, `${JSON.stringify(snapshot)}\n`, "utf8");
    return {
      path: input.out,
      frame: snapshot.runtime.frame,
      systems: snapshot.runtime.systems.length,
      resources: snapshot.simulation.resources.length,
      signals: snapshot.simulation.signals.length,
    };
  }

  async function restoreSessionSnapshot(input: {
    readonly snapshot: ApertureSessionSnapshot;
  }): Promise<unknown> {
    const restore = await replace(currentSeed, input.snapshot);
    if (restore === undefined)
      throw new Error("Missing session restore report.");
    return {
      ok: restore.ok,
      restore: jsonSafeRestoreReport(restore),
      status: compactStatus(),
    };
  }

  function callTool(input: HeadlessToolInput): GeneratedDevtoolsToolResult {
    const args = input.arguments;
    if (input.name !== "logs_read") requireActive();

    if (input.name.startsWith("ecs_")) {
      if (input.name === "ecs_pause" || input.name === "ecs_resume") {
        return {
          ok: true,
          result: {
            paused: input.name === "ecs_pause",
            note: "Headless sessions advance only when ecs_step/step is called.",
          },
        };
      }

      if (input.name === "ecs_step") {
        return { ok: true, result: step(asRecord(args)) };
      }

      if (input.name === "ecs_list_systems") {
        return {
          ok: true,
          result: { systems: listHeadlessSystems(requireActive().runner) },
        };
      }

      return requireActive().entityTools.call(input.name, args);
    }

    if (input.name.startsWith("input_")) {
      const inputResult = callInputDevtoolsTool(
        requireActive().runner.app,
        input.name,
        args,
        {
          enqueueInputEvent(event) {
            requireActive().runner.enqueueInput(
              event,
              requireActive().runner.getStatus().nextFrame,
            );
          },
        },
      );

      if (inputResult !== null) {
        return inputResult;
      }
    }

    // Composite inject verb (#71): documented as part of the headless loop,
    // it fans out to inject()/input_action_set/input_gamepad_set exactly like
    // the MCP manager's input_inject.
    if (input.name === "input_inject") {
      return inputInjectTool(asRecord(args));
    }

    if (input.name === "logs_read") {
      return logsReadTool(asRecord(args));
    }

    if (input.name === "asset_list") {
      return {
        ok: true,
        result: {
          assets: createAssetSummary(
            requireActive().runner.app.context.assets.list(),
          ),
          manifest:
            requireActive().runner.app.lowLevel.assets.createManifestReport(),
        },
      };
    }

    if (input.name === "asset_inspect") {
      const id = stringValue(asRecord(args)["id"]);
      const handle = requireActive()
        .runner.app.context.assets.list()
        .find((candidate) => candidate.id === id);

      if (id === undefined || handle === undefined || handle.kind !== "gltf") {
        return {
          ok: false,
          diagnostics: [
            {
              code: "aperture.assetInspect.gltfAssetNotFound",
              message:
                "asset_inspect requires the id of a configured glTF asset.",
            },
          ],
        };
      }

      return {
        ok: true,
        result: inspectGltfAsset(
          handle as Parameters<typeof inspectGltfAsset>[0],
          requireActive().runner.app.lowLevel.assets,
        ),
      };
    }

    if (input.name === "resource_get") {
      return resourceGet(requireActive().runner, args);
    }

    if (input.name === "resource_set") {
      return resourceSet(requireActive().runner, args);
    }

    if (input.name.startsWith("camera_")) {
      return callCameraTool(
        requireActive().runner.app,
        createApertureDevtoolsRequest({
          requestId: `headless-camera-${Date.now()}`,
          tool: input.name,
          ...(args === undefined ? {} : { payload: args }),
        }),
        requireActive().savedCameraStates,
        sessionRenderWidth / sessionRenderHeight,
      );
    }

    return unavailable(input.name);
  }

  function inputInjectTool(
    payload: Record<string, unknown>,
  ): GeneratedDevtoolsToolResult {
    assertInputInjection(payload);
    const runner = requireActive().runner;
    const events: ApertureGeneratedInputEvent[] = [];
    const results: GeneratedDevtoolsToolResult[] = [];

    if (isRecord(payload["pointer"])) {
      events.push(
        ...createApertureHeadlessInjectEvents(
          parseApertureHeadlessInjectStep({ pointer: payload["pointer"] }),
        ),
      );
      results.push({ ok: true, result: { injected: true } });
    }

    const actions = isRecord(payload["actions"]) ? payload["actions"] : {};
    for (const [action, value] of Object.entries(actions)) {
      const actionArguments =
        typeof value === "boolean"
          ? { action, pressed: value }
          : typeof value === "number"
            ? { action, value }
            : isRecord(value)
              ? { action, ...value }
              : { action, value };
      results.push(
        callInputDevtoolsTool(runner.app, "input_action_set", actionArguments, {
          enqueueInputEvent: (event) => events.push(event),
        })!,
      );
    }

    if (isRecord(payload["gamepad"])) {
      results.push(
        callInputDevtoolsTool(
          runner.app,
          "input_gamepad_set",
          payload["gamepad"],
          {
            enqueueInputEvent: (event) => events.push(event),
          },
        )!,
      );
    }

    // Preflight the entire batch, including action names/kinds, before enqueueing.
    // Otherwise a later error leaves earlier pointer/action events pending.
    const ok = results.every((result) => result.ok);
    if (ok) runner.enqueueInputBatch(events, runner.getStatus().nextFrame);
    const diagnostics = results.flatMap((result) => result.diagnostics ?? []);
    return {
      ok,
      result: { injected: ok, results },
      ...(diagnostics.length === 0 ? {} : { diagnostics }),
    };
  }

  function logsReadTool(
    payload: Record<string, unknown>,
  ): GeneratedDevtoolsToolResult {
    recordStatusDiagnostics();
    const lines = Math.max(1, Math.floor(finiteNumber(payload["lines"], 80)));
    return { ok: true, result: { entries: logEntries.slice(-lines) } };
  }

  // Fold the runner's current status diagnostics into the session log ring
  // (deduplicated), so logs_read surfaces step-time diagnostics too.
  function recordStatusDiagnostics(): void {
    if (closing || lifecycle !== "ready") return;
    for (const diagnostic of requireActive().runner.getStatus().diagnostics) {
      const key = `${diagnostic.code}:${diagnostic.message}`;
      if (loggedDiagnostics.has(key)) {
        continue;
      }
      loggedDiagnostics.add(key);
      log({
        time: new Date().toISOString(),
        level:
          diagnostic.severity === "error"
            ? "error"
            : diagnostic.severity === "warning"
              ? "warn"
              : "info",
        source: "headless-status",
        code: diagnostic.code,
        message: diagnostic.message,
        data: diagnostic,
      });
    }
  }

  function determinismReport(): unknown {
    const current = requireActive().runner.extract(
      requireActive().runner.getStatus().lastSnapshot?.frame ??
        requireActive().runner.getStatus().nextFrame,
    );
    const diagnostics = current.status.diagnostics.filter((diagnostic) =>
      diagnostic.code.startsWith("aperture.determinism."),
    );

    return {
      seed: requireActive().seed,
      determinism: options.determinism,
      nextFrame: current.status.nextFrame,
      fixedStepClock: current.status.fixedStepClock,
      diagnostics,
      digests: {
        ecs: createApertureHeadlessEcsDigest(current.status),
        status: createApertureHeadlessStatusDigest(current.status),
        render: createApertureRenderSnapshotDigest(current.snapshot),
      },
      replay: {
        deterministic: diagnostics.length === 0,
        preconditions: [
          "Use the same headless config, system modules, seed, asset mode, and fixed-step inputs.",
          "Systems must use context.random and context.time instead of nondeterministic globals.",
          "Restore SessionSnapshot artifacts before comparing continuation digests.",
        ],
        violations: diagnostics.map((diagnostic) => diagnostic.code),
      },
    };
  }

  let disposePromise: Promise<void> | null = null;
  function dispose(): Promise<void> {
    if (disposePromise === null) {
      closing = true;
      disposePromise = (async () => {
        await pendingReplacement?.catch(() => undefined);
        const previous = current;
        current = null;
        lifecycle = "disposed";
        if (previous !== null) await disposeRunner(previous.runner, log);
      })();
    }
    return disposePromise;
  }

  return {
    get lifecycle() {
      return closing ? "disposed" : lifecycle;
    },
    get runner() {
      return requireActive().runner;
    },
    get seed() {
      return currentSeed;
    },
    get initialRestoreReport() {
      return initialRestore === undefined
        ? null
        : jsonSafeRestoreReport(initialRestore);
    },
    compactStatus,
    status,
    step,
    extract,
    inject,
    pick,
    dispatchCommand,
    reset,
    callTool,
    createBundle,
    saveSessionSnapshot,
    restoreSessionSnapshot,
    determinismReport,
    dispose,
  };
}

async function bootRunner(
  options: HeadlessSessionControllerOptions,
  seed: number,
): Promise<ApertureHeadlessRunner> {
  const runner = await createApertureHeadlessRunner({
    config: options.config,
    systems: options.systems,
    assetLoader: createNodeApertureAssetLoader({
      mode: options.assetMode,
      root: options.root,
      publicDir: options.publicDir,
      allowHttp: options.allowHttpAssets,
      ...(options.decoderAssetsDir === undefined
        ? {}
        : { decoderAssetsDir: options.decoderAssetsDir }),
    }),
    random: seed,
    determinism: { globals: options.determinism },
  });
  await runner.app.preload;
  return runner;
}

function logPlaceholders(
  log: (entry: HeadlessSessionLogEntry) => void,
  runner: ApertureHeadlessRunner,
): void {
  const placeholders =
    runner.app.lowLevel.assets.createManifestReport().placeholders;
  for (const id of placeholders.ids) {
    log({
      time: new Date().toISOString(),
      level: "warn",
      source: "asset-loader",
      code: "aperture.headless.assetPlaceholder",
      message: `Asset '${id}' loaded as a Node placeholder.`,
      data: { id },
    });
  }
}

function listHeadlessSystems(
  runner: ApertureHeadlessRunner,
): readonly Record<string, unknown>[] {
  return (runner.app.lowLevel.world.getSystems() as readonly unknown[]).map(
    (system, index) => {
      const constructor = isRecord(system) ? system["constructor"] : undefined;
      const className =
        typeof constructor === "function" && constructor.name.length > 0
          ? constructor.name
          : `System ${index}`;
      const aperture =
        typeof constructor === "function"
          ? (constructor as unknown as Record<string, unknown>)["aperture"]
          : undefined;
      const schedule = isRecord(aperture) ? aperture["schedule"] : undefined;
      const metadataPriority =
        isRecord(schedule) && typeof schedule["priority"] === "number"
          ? schedule["priority"]
          : null;
      // The registered system instance carries the priority the world orders
      // execution by — authoritative for built-in systems that lack the
      // `aperture` static metadata. Surface it as a top-level numeric priority
      // (F14) while keeping the nested value for back-compat.
      const instancePriority =
        isRecord(system) && typeof system["priority"] === "number"
          ? system["priority"]
          : null;
      const priority = instancePriority ?? metadataPriority;

      return {
        index,
        moduleId: className,
        className,
        priority,
        schedule: { priority: metadataPriority },
      };
    },
  );
}

async function disposeRunner(
  runner: ApertureHeadlessRunner,
  log: (entry: HeadlessSessionLogEntry) => void,
): Promise<void> {
  for (const error of await disposeHeadlessRunner(runner)) {
    try {
      log({
        time: new Date().toISOString(),
        level: "warn",
        source: "session-controller",
        code: "aperture.headless.runnerDisposeFailed",
        message: headlessDisposeFailureMessage(error),
        data: error instanceof Error ? { name: error.name } : { error },
      });
    } catch {
      /* Cleanup evidence is retained by the app lifecycle owner. */
    }
  }
}

function resourceGet(
  runner: ApertureHeadlessRunner,
  payload: unknown,
): GeneratedDevtoolsToolResult {
  const record = asRecord(payload);
  const id = stringValue(record["id"]);

  if (Object.prototype.hasOwnProperty.call(record, "id")) {
    if (id === undefined || id.trim().length === 0) {
      return {
        ok: false,
        diagnostics: [
          {
            code: "aperture.resource.invalidDevtoolsId",
            severity: "error",
            message: "resource_get id must be a non-empty string.",
            suggestedFix:
              "Pass { id: 'your.resource.id' }, or omit id to list all generated app resources.",
          },
        ],
      };
    }
  }

  const summary = runner.app.context.resources.summary();
  if (id === undefined) {
    return { ok: true, result: { resources: summary } };
  }

  const resource = summary.entries.find((entry) => entry.id === id) ?? null;
  if (resource === null) {
    return {
      ok: false,
      result: {
        id,
        resource: null,
        resources: { count: 0, entries: [] },
      },
      diagnostics: [resourceNotFoundDiagnostic(id)],
    };
  }

  return {
    ok: true,
    result: {
      id,
      resource,
      resources: { count: 1, entries: [resource] },
    },
  };
}

function resourceSet(
  runner: ApertureHeadlessRunner,
  payload: unknown,
): GeneratedDevtoolsToolResult {
  const record = asRecord(payload);
  const id = stringValue(record["id"]);
  if (id === undefined || id.trim().length === 0) {
    return {
      ok: false,
      diagnostics: [
        {
          code: "aperture.resource.invalidDevtoolsId",
          severity: "error",
          message: "resource_set id must be a non-empty string.",
          suggestedFix:
            "Pass { id: 'your.resource.id', values: { fieldName: value } }.",
        },
      ],
    };
  }

  const values = record["values"] ?? record["fields"];
  if (!isRecord(values) || Object.keys(values).length === 0) {
    return {
      ok: false,
      diagnostics: [
        {
          code: "aperture.resource.invalidDevtoolsValues",
          severity: "error",
          message: "resource_set values must be a non-empty object.",
          suggestedFix:
            "Pass { values: { fieldName: value } } using fields reported by resource_get.",
        },
      ],
    };
  }

  try {
    const resource = runner.app.context.resources.patchById(id, values);
    if (resource === null) {
      return {
        ok: false,
        result: {
          id,
          resource: null,
          resources: { count: 0, entries: [] },
        },
        diagnostics: [resourceNotFoundDiagnostic(id)],
      };
    }

    return {
      ok: true,
      result: {
        id,
        resource,
        resources: { count: 1, entries: [resource] },
      },
    };
  } catch (error: unknown) {
    if (isSystemErrorLike(error)) {
      return {
        ok: false,
        diagnostics: [
          errorToApertureDiagnostic(error, {
            code: error.code,
            severity: "error",
            message: error.message,
            suggestedFix:
              error.suggestedFix ??
              "Inspect resource_get field kinds and pass values matching the declared resource schema.",
          }),
        ],
      };
    }

    throw error;
  }
}

function resourceNotFoundDiagnostic(
  id: string,
): Readonly<Record<string, unknown>> {
  return {
    code: "aperture.resource.notFound",
    severity: "warning",
    message: `Generated app resource '${id}' was not found.`,
    suggestedFix:
      "Call resource_get without an id to list resources currently initialized by generated worker systems.",
  };
}

function jsonSafeRestoreReport(value: unknown): unknown {
  if (!isRecord(value)) {
    return value;
  }

  const scene = isRecord(value["scene"]) ? value["scene"] : {};
  const sceneEntities = Array.isArray(scene["entities"])
    ? scene["entities"].length
    : 0;

  return {
    ok: value["ok"] === true,
    scene: {
      ok: scene["ok"] === true,
      entities: sceneEntities,
      diagnostics: Array.isArray(scene["diagnostics"])
        ? scene["diagnostics"]
        : [],
    },
    sourceAssets: value["sourceAssets"],
    resources: value["resources"],
    signals: value["signals"],
    random: value["random"],
    fixedStepClock: value["fixedStepClock"],
    systems: value["systems"],
  };
}

interface DeterminismViolation {
  readonly code: string;
  readonly system: string;
  readonly phase: string;
  readonly api: string;
  readonly suggestedApi: string;
}

function determinismViolations(
  diagnostics: ApertureHeadlessStatus["diagnostics"],
): DeterminismViolation[] {
  return diagnostics
    .filter(
      (diagnostic) =>
        diagnostic.code === "aperture.determinism.nondeterministicGlobal",
    )
    .map((diagnostic) => {
      const data = (diagnostic.data ?? {}) as Record<string, unknown>;
      const stringField = (key: string, fallback: string): string =>
        typeof data[key] === "string" ? (data[key] as string) : fallback;
      return {
        code: diagnostic.code,
        system: stringField("system", "unknown system"),
        phase: stringField("phase", "unknown phase"),
        api: stringField("api", "unknown API"),
        suggestedApi: stringField(
          "suggestedApi",
          "context.random/context.time",
        ),
      };
    });
}

function describeDeterminismViolations(
  violations: readonly DeterminismViolation[],
): string {
  return violations
    .map(
      (violation) =>
        `${violation.system} called ${violation.api} during ${violation.phase} (use ${violation.suggestedApi})`,
    )
    .join("; ");
}

/**
 * Digest used for quiescence comparison. Reuses the exact digest function the
 * step/extract `digest: true` paths emit (createApertureRenderSnapshotDigest),
 * with the `frame`/`time` stamps normalized out: they advance every step even
 * in a fully settled scene, and quiescence compares extraction *content*, not
 * timestamps (agent-stumble: brittle waits).
 */
function quiescenceDigestHash(snapshot: RenderSnapshot): string {
  return createApertureRenderSnapshotDigest({ ...snapshot, frame: 0, time: 0 })
    .hash;
}

/**
 * Resolve a raycast hit's render entity ref to the same stable id shape
 * ecs_find_entities reports ({ index, generation } plus key/name when the
 * entity is alive and authored with them).
 */
function pickHitFromRaycast(
  world: EcsWorld,
  hit: RaycastHit<MeshDrawPacket>,
): HeadlessPickHit {
  const draw = hit.entity;
  const report = getApertureEntitySummary(world, draw.entity);
  const summary = report.ok ? report.summary : null;

  return {
    entity: { index: draw.entity.index, generation: draw.entity.generation },
    ...(summary?.key === undefined ? {} : { key: summary.key }),
    ...(summary === null ? {} : { name: summary.name }),
    renderId: draw.renderId,
    distance: hit.distance,
    point: vec3Tuple(hit.point),
    boundsIndex: draw.boundsIndex,
  };
}

function vecComponent(values: ArrayLike<number>, index: number): number {
  return values[index] ?? 0;
}

interface PickRect {
  readonly left: number;
  readonly top: number;
  readonly right: number;
  readonly bottom: number;
  readonly width: number;
  readonly height: number;
}

/**
 * Resolve a normalized view rectangle (viewport or scissor) to the integer
 * pixel rect the renderer actually uses, mirroring its rounding-and-clamping
 * rules (see packages/webgpu view-rectangle resolution). Returns null for an
 * empty rectangle.
 */
function resolvePickRect(
  rect: ArrayLike<number>,
  targetWidth: number,
  targetHeight: number,
): PickRect | null {
  const normalizedX = vecComponent(rect, 0);
  const normalizedY = vecComponent(rect, 1);
  const normalizedWidth = vecComponent(rect, 2);
  const normalizedHeight = vecComponent(rect, 3);
  const left = clampInteger(Math.round(normalizedX * targetWidth), targetWidth);
  const top = clampInteger(
    Math.round(normalizedY * targetHeight),
    targetHeight,
  );
  const right = clampInteger(
    Math.round((normalizedX + normalizedWidth) * targetWidth),
    targetWidth,
  );
  const bottom = clampInteger(
    Math.round((normalizedY + normalizedHeight) * targetHeight),
    targetHeight,
  );
  const width = right - left;
  const height = bottom - top;

  if (width <= 0 || height <= 0) {
    return null;
  }

  return { left, top, right, bottom, width, height };
}

function intersectPickRects(
  a: PickRect | null,
  b: PickRect | null,
): PickRect | null {
  if (a === null || b === null) {
    return null;
  }

  const left = Math.max(a.left, b.left);
  const top = Math.max(a.top, b.top);
  const right = Math.min(a.right, b.right);
  const bottom = Math.min(a.bottom, b.bottom);
  const width = right - left;
  const height = bottom - top;

  if (width <= 0 || height <= 0) {
    return null;
  }

  return { left, top, right, bottom, width, height };
}

function clampInteger(value: number, maximum: number): number {
  return Math.min(Math.max(value, 0), maximum);
}

function withOptionalDigests<T extends object>(
  result: T,
  params: { readonly digest?: unknown },
  status: ApertureHeadlessStatus,
  snapshot?: RenderSnapshot,
): T & {
  readonly digests?: {
    readonly ecs: ReturnType<typeof createApertureHeadlessEcsDigest>;
    readonly status: ReturnType<typeof createApertureHeadlessStatusDigest>;
    readonly snapshot?: ReturnType<typeof createApertureRenderSnapshotDigest>;
  };
} {
  if (params.digest !== true) {
    return result;
  }

  return {
    ...result,
    digests: {
      ecs: createApertureHeadlessEcsDigest(status),
      status: createApertureHeadlessStatusDigest(status),
      ...(snapshot === undefined
        ? {}
        : { snapshot: createApertureRenderSnapshotDigest(snapshot) }),
    },
  };
}

function unavailable(name: string): GeneratedDevtoolsToolResult {
  return {
    ok: false,
    diagnostics: [
      {
        code: "aperture.headless.toolUnavailable",
        message:
          `Tool '${name}' is not available in a headless session. ` +
          "Headless sessions support ecs_* (except ecs_step_and_diff), " +
          "camera_*, asset_list, asset_inspect, resource_get/resource_set, logs_read, and " +
          "these input tools: input_inject, input_action_set, " +
          "input_gamepad_set, input_get_state, input_reset. Raw-device " +
          "tools (input_key, input_pointer_*) need the headed browser slot; " +
          "headlessly, drive the action layer with " +
          "input_action_set({ action, x, y }) or the gamepad path with " +
          "input_gamepad_set({ left: { x, y } }) instead.",
      },
    ],
  };
}

function asRecord(value: unknown): Record<string, unknown> {
  return isRecord(value) ? value : {};
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isSystemErrorLike(value: unknown): value is {
  readonly code: string;
  readonly message: string;
  readonly suggestedFix?: string;
  readonly detail?: unknown;
} {
  return (
    isRecord(value) &&
    typeof value["code"] === "string" &&
    typeof value["message"] === "string"
  );
}

function stringValue(value: unknown): string | undefined {
  return typeof value === "string" && value.length > 0 ? value : undefined;
}

function finiteNumber(value: unknown, fallback: number): number {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function positiveIntegerValue(value: unknown, fallback: number): number {
  return typeof value === "number" && Number.isInteger(value) && value > 0
    ? value
    : fallback;
}

/**
 * Parse a JSON-object/array-shaped string payload back into a structured
 * value. Only strings whose first non-whitespace character is `{` or `[` are
 * candidates — plain strings, numbers-as-strings, and malformed JSON pass
 * through untouched so a legitimate string payload is never reinterpreted.
 */
function coerceJsonStringPayload(payload: unknown): {
  readonly payload: unknown;
  readonly wasCoerced: boolean;
} {
  if (typeof payload !== "string") {
    return { payload, wasCoerced: false };
  }

  const first = payload.trimStart()[0];

  if (first !== "{" && first !== "[") {
    return { payload, wasCoerced: false };
  }

  try {
    return { payload: JSON.parse(payload) as unknown, wasCoerced: true };
  } catch {
    return { payload, wasCoerced: false };
  }
}
