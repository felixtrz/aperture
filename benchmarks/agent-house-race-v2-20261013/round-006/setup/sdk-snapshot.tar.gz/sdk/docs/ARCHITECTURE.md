# Architecture

## Summary

This project is a WebGPU-only, ECS-first 3D runtime.

The core architecture is:

```text
ECS World
  -> Systems / Transform Resolution
  -> Render Extraction
  -> Render Snapshot
  -> Render World
  -> WebGPU Render Graph
  -> GPU Submission
```

The ECS world is authoritative. Rendering is a derived view of ECS state.

The [agent architecture audit](AGENT_ARCHITECTURE_AUDIT.md) records the
2026-10-11 reliability repairs, the comparison with Immersive Web SDK's current
AI tooling, and the remaining source-isolation and readiness design work.

There is no public three.js-style mutable scene graph as the central world model.

## Package Boundaries

Aperture is organized as a pnpm workspace with package boundaries that mirror
the runtime architecture:

- `@aperture-engine/simulation`: headless ECS, assets, diagnostics, math, and
  transform ownership. It must not import render, runtime, WebGPU, or browser
  globals.
- `@aperture-engine/physics`: backend-neutral physics authoring components,
  fixed-step clock helpers, backend command/result contracts, query/event
  contracts, and test backends. It may import simulation, but not render,
  runtime, WebGPU, browser globals, or concrete physics engine packages.
- `@aperture-engine/render`: renderer-independent authoring components, mesh
  and material asset contracts, render extraction, snapshots, render world data,
  and diagnostics. It may import simulation, but not WebGPU.
- `@aperture-engine/webgpu`: the explicit WebGPU backend and browser app
  facade. It consumes render snapshots/render-world data and owns GPU resources,
  render passes, pipelines, bind groups, command encoding, and submission.
- `@aperture-engine/app`: the default developer-facing app facade. Its
  `config`, `systems`, and `advanced` entry points are headless-safe app
  ergonomics over the lower layers. Browser-specific generated bootstrap lives
  behind the `browser` and `worker` entry points, not the root export. App
  systems may implement `fixedUpdate(context)` for deterministic fixed-step
  work, or explicitly register advanced tasks through
  `this.fixedStep.register(...)`; the app wires both routes to the runtime
  fixed-step scheduler when systems are created through `createApertureApp()`.
  The systems facade also owns typed app resources/singletons through
  `defineResource(...)`, `resource.*`, and `this.resources`; these resources are
  simulation-worker state and are summarized through generated worker/headless
  status, not renderer-owned objects.
  Systems that produce runtime mesh data can publish renderer-independent
  `MeshAsset` updates through `this.meshes.dynamic(...)`, keeping asset
  registration and version bumps out of app-local registry plumbing.
- `@aperture-engine/vite-plugin`: the default Vite integration. It discovers
  `aperture.config.ts`, system globs, system descriptor metadata, and generated
  browser/worker virtual modules. It is build-time code and is intentionally not
  exported by the root `@aperture-engine/app` entry; the optional
  `@aperture-engine/app/vite` subpath re-exports it for projects that prefer the
  app namespace.
- `@aperture-engine/runtime`: headless simulation and extraction app facades.
  It composes simulation, physics execution hooks, and render extraction only;
  WebGPU app orchestration belongs in `@aperture-engine/webgpu`.

Normal app authors start with `@aperture-engine/app/config`,
`@aperture-engine/app/systems`, and `@aperture-engine/vite-plugin`. Users who
need custom GPU presentation should import `@aperture-engine/webgpu`
explicitly alongside the focused simulation, render, and runtime packages they
need.

The default browser application shape is now a Vite metaframework path:

- `aperture.config.ts` declares browser/headless mode, canvas, system globs,
  assets, render defaults, input, signals, and diagnostics.
- `vite.config.ts` installs `aperture()` from
  `@aperture-engine/vite-plugin`.
- The generated main-thread bootstrap owns presentation, input forwarding,
  diagnostics, worker startup, WebGPU submission, and resize.
- The generated worker registers discovered system modules in priority order,
  owns ECS state, runs registered fixed-step tasks before transform resolution,
  resolves transforms, and extracts `RenderSnapshot` data.
- Worker systems share singleton app state through typed resources on
  `this.resources`. Resource values must stay structured-clone safe and must not
  hold GPU, DOM, Web Audio, or renderer handles.
- Worker systems publish dynamic mesh source data through `this.meshes`.
  Meshes remain source assets in the registry; GPU buffers remain renderer-owned
  and are refreshed from asset versions.
- App-level browser URL/start fields forwarded to the worker are available to
  systems through `this.startOptions`. Engine-reserved worker fields such as
  snapshot transport buffers stay out of that public system view.
- The boundary is structured-clone/transferable snapshot data plus explicit
  command messages. Main-thread code does not receive live system classes and
  does not own authoritative simulation state.

The WebGPU facade is convenience orchestration over the same
ECS/render-extraction/WebGPU boundary; it must not become a hidden scene graph or
make WebGPU state part of the authoritative ECS world. Lower-level WebGPU
helpers remain backend and test surfaces.

## The ECS → Render Bridge

Aperture's ECS-to-render bridge follows a single principle: rendering is a
derived view of authoritative ECS state.

- Main/simulation ECS state is authoritative.
- An entity becomes renderable only by adding render-facing components.
- Meshes, materials, textures, samplers, and environment maps are assets
  referenced by stable handles from components.
- Render extraction copies only render-relevant ECS data into a derived render
  representation.
- Render asset preparation turns source assets into renderer-owned GPU-ready
  resources.
- Draw queueing, phase sorting, and WebGPU command submission happen after
  extraction and preparation.

Aperture keeps a serializable `RenderSnapshot` as its worker-ready boundary. A
future render world may grow richer internal structure, but it must not become
authoritative gameplay state.

## Primary Layers

### ECS / Simulation Layer

Owns:

- Entities.
- Components.
- Systems.
- Resources/singletons.
- Commands.
- Events.
- Game/app logic.
- Transform hierarchy.
- Simulation state.

The ECS layer does not own GPU resources. App resources are for authoritative
simulation or app coordination state that needs one value per world, such as a
player vehicle state, clock, mode, or score cache. They are not a scene graph and
must remain inspectable as JSON-safe worker/headless summaries.

### Render Extraction Layer

Reads ECS state and produces a render-facing representation.

Responsibilities:

- Query entities with renderable components.
- Read resolved world transforms.
- Apply visibility and layer filtering.
- Resolve mesh/material handles.
- Produce render packets.
- Produce render snapshots.
- Generate diagnostics for skipped/invalid renderables.
- Extract shadow caster draw packets separately from main-view mesh draw
  packets, so main-camera frustum culling never determines whether an
  off-screen caster can still contribute to a shadow map.

This is the key boundary that allows future worker-thread simulation.

### Render Snapshot

A compact representation of what should be rendered for a frame or state update.

Should be:

- Typed.
- Serializable.
- Stable.
- Diffable eventually.
- Suitable for worker-to-main-thread transport.
- Free of arbitrary JS object graph dependencies.

### Render World

Main-thread/render-thread representation of renderable state.

Owns:

- Render objects.
- Prepared mesh assets.
- Prepared material assets.
- Prepared texture and sampler resources.
- GPU-facing resource references.
- Draw queues / phase items.
- Material/pipeline grouping.
- Draw sorting state.
- Batching state.
- Render diagnostics.

The render world is not authoritative gameplay state.

### WebGPU Backend

Owns:

- GPU device.
- Canvas context.
- Buffers.
- Textures.
- Samplers.
- Bind groups.
- Pipelines.
- Render passes.
- Command encoding.
- Submission.

WebGPU code should be isolated from ECS logic.

### Frame Hot Path Allocation Discipline

Render-pipeline code that runs every frame should avoid steady-state heap
allocation. Per-frame stages may write into caller-owned scratch buffers,
stable pools, typed arrays, or prebuilt report shells, but they should not build
fresh arrays, maps, closures, descriptor objects, or diagnostic wrappers on the
success path.

Allocation is acceptable for setup, asset preparation, pipeline creation,
one-shot planning helpers, tests, examples, and failure diagnostics. If a helper
allocates for convenience, it should either stay outside the frame loop or be
paired with a reusable writer/scratch API for runtime use.

## Transform Ownership

Transforms belong to the ECS layer.

The renderer consumes resolved world transforms.

Suggested component split:

- `LocalTransform`
- `Parent`
- `WorldTransform`
- optional `TransformDirty`

The renderer should never compute gameplay hierarchy itself.

## Spatial Queries

CPU spatial queries belong below the WebGPU backend and execute synchronously in
the logic/simulation context. Exact mesh raycasts, mesh BVHs, BVH traversal,
closest-point queries, and entity-bounds BVHs run over renderer-independent CPU
mesh/bounds data in `@aperture-engine/simulation`, with a thin
`@aperture-engine/render` adapter for source `MeshAsset` buffers. Aperture does
not create a separate BVH worker or expose async query promises for gameplay
logic. WebGPU ID-buffer picking remains a visual/editor convenience derived from
render snapshots; it is not the authoritative gameplay query path.
ID-buffer selection covers rasterized mesh geometry regardless of material
opacity, alpha cutouts or custom fragment discard. This lets editors select
transparent geometry as well as opaque surfaces.

## Render Authoring Components

Initial ECS-facing render components may include:

- `Mesh`
- `Material`
- `Camera`
- `Visibility`
- `RenderLayer`
- `Name`
- `DebugMetadata`
- `Light`
- `LightShadowSettings`

These are semantic app-facing components. They should not contain WebGPU-specific state.

The preferred mesh authoring direction stores mesh and material handles in
separate components, with unsuffixed names because Aperture is a 3D-only
runtime. The early combined `MeshRenderer` component has been removed from the
active API.

- `Mesh`: stable `MeshHandle`.
- `Material`: stable material handle for the entity's primary mesh material.
- `MaterialSlots` or separate primitive entities later for multi-material meshes.

This keeps the entity as logic identity and makes renderability opt-in through
components rather than through renderer-owned objects.

Light and environment authoring follow the same ECS-owned rule as mesh and
camera authoring. Ambient and environment inputs are global and can be extracted
without a `WorldTransform`: ambient authoring emits a `LightPacket`, while
environment authoring emits an `EnvironmentPacket`. ECS environment authoring may
store only a stable environment-map asset handle; renderer-owned texture views,
samplers, bind groups, skybox state, and shader consumption remain outside ECS.
Extraction validates authored environment-map handle readiness and copies the
handle into `EnvironmentPacket.handle` when ready, or emits diagnostics and omits
only the invalid environment packet. Directional, point, and spot lights require
`WorldTransform` because extraction derives their render-facing position and
orientation from ECS transform data; missing transforms should produce
diagnostics instead of renderer-owned fallback state.

Shadow settings are also ECS-owned authoring data. Extraction emits flat
`ShadowRequestPacket`s for supported lights or diagnostics for unsupported
requests. Shadow cameras, maps, passes, filtering resources, and pipelines are
renderer-owned derived state and are never stored on ECS components.

Renderer-side light/environment preparation starts from extracted packets, not
ECS. The renderer packs `LightPacket`s into GPU buffers and derives stable
environment resource keys from `EnvironmentPacket.handle`. It owns the light
bind groups, shadow resources, HDR projection, diffuse irradiance, specular
PMREM, samplers, StandardMaterial IBL bind groups, and specialized pipelines.
Empty lighting snapshots remain valid no-ops. Cache and readiness summaries
expose stable keys, counts, versions, and diagnostics without raw WebGPU
handles.

StandardMaterial direct lighting and diffuse/specular IBL are executable paths.
Frame readiness distinguishes resource preparation from what
the submitted pipeline actually sampled; `iblDiffuse`, `iblSpecularBrdf`, and
`iblSpecularProof` pipeline tokens are the activation record. The authoritative
end-to-end IBL description and readiness states live in
[`architecture/standard-material-ibl.md`](./architecture/standard-material-ibl.md).
The packed-light WGSL declaration and JSON-safe inspection surfaces are
documented in [`LIGHT_SHADER_WGSL_CONTRACT.md`](./LIGHT_SHADER_WGSL_CONTRACT.md).

## Assets and Handles

The ECS should reference assets through stable handles.

Examples:

- `MeshHandle`
- `MaterialHandle`
- `TextureHandle`
- `ShaderHandle`
- `AssetHandle`

GPU objects are created and owned by the renderer/asset backend, not by ECS components.

Common authoring should move toward typed asset collections over the generic
registry:

- `Assets<MeshAsset>`
- `Assets<UnlitMaterialAsset>`
- `Assets<MatcapMaterialAsset>`
- `Assets<StandardMaterialAsset>`
- `Assets<TextureAsset>`
- `Assets<SamplerAsset>`
- `Assets<WgslShaderAsset>`

The generic `AssetRegistry` can remain the manifest, status, dependency, and
diagnostic substrate. Typed collections should be the ergonomic API for adding,
updating, and looking up source assets.

Renderer-owned prepared assets should be produced by explicit render asset
adapters. A render asset adapter maps a source asset and its version/dependency
state into a prepared renderer resource such as uploaded mesh buffers, material
bind data, texture views, samplers, or pipeline keys.

Texture source assets may include uploadable texel bytes and row-layout metadata
as renderer-independent source data. That source payload is not a GPU resource:
the WebGPU backend is responsible for turning it into `GPUQueue.writeTexture`
work and prepared texture views keyed by source handle/version.

Shader source assets follow the same rule. A `WgslShaderAsset` is WGSL text plus
metadata such as label, URL, and virtual path. It is mirrored across the
worker/main source-asset channel by handle/version. The WebGPU backend is the
only layer that may create `GPUShaderModule` objects from it.

Custom WGSL material assets are source material assets with a
`sourceDiscriminator: "custom-material-source"` instead of a built-in
`MaterialKind`. They carry a namespaced `familyKey`, render state, shader ref,
entry points, pipeline-key inputs, data-only bindings, dependencies, optional
instance attributes, and JSON-safe metadata. Built-in material families remain
reserved, and unsupported custom families diagnose instead of falling back to a
built-in material.

The current renderer-owned custom WGSL app route reserves these groups:

- `group(0) binding(0)`: view uniform.
- `group(1) binding(0)`: world transform storage.
- `group(2)`: custom material bindings.
- `group(3)`: future renderer extensions.

V1 supports path-loaded or inline WGSL, renderer-owned uniform-buffer material
bindings, texture bindings, sampler bindings, existing instance-attribute
layouts, and mixed built-in/custom frames through the normal app route. Storage
binding declarations are part of the source contract and dependency readiness
path, but unsupported app-route resource creation must diagnose with JSON-safe
records until renderer-independent buffer source assets are implemented.

Texture assets also carry renderer-independent `semantic` and `colorSpace`
metadata. The current color-management contract is documented in
[`COLOR_MANAGEMENT.md`](./COLOR_MANAGEMENT.md): StandardMaterial renders in
linear RGB, base-color/emissive textures use sRGB source formats, data textures
stay linear/data, and browser StandardMaterial output tonemaps before sRGB
display encoding.

The current renderer-independent contract is documented in
[`RENDER_ASSET_PREPARATION.md`](./RENDER_ASSET_PREPARATION.md). It defines
typed prepare/unload adapters and prepared mesh/material stores without exposing
raw WebGPU handles.

## Frame Pipeline

A typical single-threaded frame:

```text
1. Input collection
2. Command processing
3. Fixed update, if needed
4. Simulation systems
5. Transform resolution
6. Render extraction
7. Render asset extraction / change collection
8. Render asset preparation
9. Draw queueing
10. Phase sorting
11. WebGPU render graph execution
12. GPU submit
13. Cleanup
```

The default browser split-thread frame:

```text
Worker:
  1. Read input command stream
  2. Run simulation
  3. Resolve transforms
  4. Extract render snapshot
  5. Publish snapshot

Main:
  1. Collect input
  2. Write input command stream
  3. Read latest complete render snapshot
  4. Apply render snapshot to render world
  5. Prepare changed render assets
  6. Queue and sort draw items
  7. Render via WebGPU
```

Fixed-step simulation and presentation can run at different cadences. App
systems that implement `fixedUpdate(context)` are registered in system-priority
order on the runtime fixed-step scheduler. Entities that opt into
`RenderInterpolation` keep previous/current fixed-step transform samples in ECS;
after extraction, the app rewrites only the outgoing `RenderSnapshot`
transforms and view matrices using the current fixed-step overstep alpha.
Interpolated local samples compose through the normal ECS transform hierarchy:
a render packet under an interpolated parent uses that parent's presentation
matrix plus the child's current local transform unless the child also opted into
interpolation. The authoritative ECS `LocalTransform` and `WorldTransform`
values remain the fixed simulation state, and render interpolation does not
introduce a renderer-owned scene graph.

The canonical submitted-frame diagnostics taxonomy lives in
`packages/webgpu/src/render/frame/render-frame-phases.ts` and is:

```text
apply -> prepare -> queue -> resolve -> command -> submit
```

This taxonomy starts after the ECS worker has published a `RenderSnapshot`.
Extraction, asset change collection, and renderer-owned resource preparation
remain first-class architecture boundaries, but they are broader app/render
pipeline stages rather than the canonical WebGPU frame-summary phase names.

## Multithreading Design Direction

The renderer must never require direct access to the authoritative ECS world.

Default worker mode currently uses transferable typed-array `postMessage`
snapshots. High-scale worker mode is opt-in and builds on the shared transport
foundation now exposed by runtime and render:

- `createSharedSnapshotTransport({ maxEntities, maxViews })` allocates
  double-buffered SharedArrayBuffer storage for transforms and view matrices.
- Atomics publish complete frames through a SeqLock-style header.
- `encodeSnapshotPackets()` writes view, mesh, light, environment, shadow, and
  bounds packet metadata as fixed-stride `Uint32Array` records.
- Input command ring buffer.
- Render snapshot publication through `createWebGpuApp({
transport: "shared-array-buffer" })`.
- `postMessage` for cold-path data such as debug names, asset metadata, and errors.

Hot data candidates:

- transforms
- view matrices
- fixed-stride render packet metadata
- visibility flags
- instance data
- input samples
- frame counters

Cold data candidates:

- debug names
- asset registration
- error reports
- schema metadata
- large scene changes

## Material System

Materials should be data-driven.

A material should describe:

- shader family
- parameters
- texture handles
- render state
- feature flags

The renderer resolves materials into:

- pipeline keys
- bind groups
- uniform/storage buffer layouts
- batching compatibility

Material diagnostics should explain performance costs where possible.

Near-term material families should progress from unlit, to matcap/normal-view
preview material, to glTF-aligned StandardMaterial. A cheaper Lambert/Phong-style
material is optional later, not a prerequisite for the StandardMaterial proof
path.

## Diagnostics

Diagnostics are part of the architecture, not an afterthought.

Current renderer frame readiness report relationships are documented in [`RENDER_FRAME_READINESS.md`](./RENDER_FRAME_READINESS.md).

The runtime should eventually provide:

- `inspectEntity(entity)`
- `explainVisibility(entity)`
- `getFrameReport()`
- `getRenderPacketReport()`
- `getAssetValidationReport()`
- `getBatchingReport()`

Agents and humans should be able to understand why something rendered, failed to render, or rendered slowly.

## Agent-Friendliness

The architecture should be easy for coding agents to work with.

Prefer:

- explicit schemas
- strong TypeScript types
- small modules
- clear file ownership
- deterministic systems
- actionable errors
- stable docs
- small backlog tasks
- tests for every subsystem

Avoid:

- hidden global mutable state
- vague lifecycle hooks
- uncontrolled plugin mutation
- large unreviewed rewrites
- object graphs that cannot be serialized or inspected

## Architecture Invariants

These should not be violated without updating `docs/DECISIONS.md`:

1. ECS is the source of truth.
2. Rendering is a derived view.
3. WebGPU is the only rendering backend.
4. The renderer does not expose a central mutable scene graph.
5. Transform hierarchy belongs to ECS.
6. GPU resources belong to renderer/backend.
7. Render extraction is a first-class boundary.
8. Worker simulation remains the browser default; renderer APIs must preserve
   the snapshot/command boundary.
