# Author journal

- 2026-10-17T06:39:07Z — Timer started; read repository AGENTS, frozen benchmark protocol and visual-quality guidance. Inspected reference. Chose an orthographic west/south view and a small square street diorama, modeled procedurally.
- 2026-10-17T06:43:00Z — First scene authored: café and bookshop with readable shopfronts, roof details, awnings, sidewalk, roads, crossing, two cars, two trees, lamps, bench and café seating. Uses Three.js WebGPURenderer with its automatic fallback explicitly disabled; still frame waits for verifier GPU completion.

- 2026-10-17T06:44:38Z — Capture `first` passed native WebGPU verification: 0 WebGL attempts, no GPU errors. Capture queue waited 67.2 seconds; render/lifecycle 3.8 seconds. Inspection found hidden café text, overly smooth trees, flat lighting, and a low viewing angle.
- 2026-10-17T06:46:40Z — Raised sign visibility by lowering awnings, replaced tree clusters with faceted irregular canopies, moved foliage outward, enlarged cars modestly, adjusted camera elevation and lighting, darkened asphalt, and added restrained GTAO contact shading. Changed removed PCFSoftShadowMap to supported PCFShadowMap after reading current Three source.

- 2026-10-17T06:46:53Z — Capture `refined` failed: GTAO attempted WGSL textureGather on multisampled depth, rejected by WebGPU validation. No PNG was produced. Read current PassNode/GTAO docs and switched to a single-sample normal/depth prepass with AO applied to the MSAA beauty pass, the documented integration. Added explicit uncaptured GPU-error collection to readiness status.

- 2026-10-17T06:48:11Z — Capture `ao-fixed` passed; inspected its PNG. Three captures used including one failure. Composition and shading improved.
- 2026-10-17T06:50:20Z — Final refinement: flattened protruding stone quoins, enlarged lettering, defined warm shop lighting against darker glazing, corrected authored car-cabin face winding, and applied GTAO denoising with an explicitly seeded noise texture.

- 2026-10-17T06:50:40Z — Capture `final` failed: denoise inline in the material AO context sampled a depth texture while it was an active attachment. GPU error collection correctly signaled `{ok:false}`. No PNG was produced. Materialized denoising into an independent RTT texture pass before screen-space sampling.
