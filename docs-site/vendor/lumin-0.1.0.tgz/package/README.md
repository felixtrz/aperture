# Lumin

A dark-first React design system. Born from the **IWSDK Adventures** visual
language (`design.pen`) and built to grow into a full product design system.

- **Dark mode first** — a structured token set (`[data-theme="dark"]`), with a
  `[data-theme="light"]` override addable additively.
- **Monospace UI voice** — Geist / Inter / Geist Mono, amber accent, cyan for
  tooling/MCP.
- **Self-styling** — `lumin/styles.css` carries fonts, tokens, and every
  component's CSS.
- **Icons** — standardized on [Lucide](https://lucide.dev/icons/)
  (`lucide-react`).

## Install

```sh
pnpm add lumin react react-dom
```

## Use

```tsx
import { Hero, Badge, Button } from "lumin";
import "lumin/styles.css"; // tokens + component styles
import "lumin/fonts.css"; // self-hosted brand fonts (Geist / Inter / Geist Mono)

export function Landing() {
  return (
    <Hero
      badge={<Badge tone="accent" dot>live · 7 projects</Badge>}
      title={<>No magic.<br />Just the loop.</>}
      subtitle="One agent + immersive web build per project."
      actions={<Button variant="primary" pill>latest: rocket →</Button>}
    />
  );
}
```

Prefer one import at your app root? `import "lumin/global.css"` bundles fonts +
tokens + a page reset (use it alongside `lumin/styles.css`). Raw tokens are at
`lumin/tokens.css`. Fonts are self-hosted (woff2 shipped in the package).

## Components

| Group | Components |
|---|---|
| Primitives | `Button`, `Badge`, `Card`, `Input`, `Stack`, `Divider`, `MonoTag`, `Avatar` |
| Brand | `ClaudeMark`, `CodexMark`, `AgentMark` |
| Content | `Markdown`, `UserBubble`, `AssistantBubble`, `Checkpoint`, `Redaction`, `TruncationDivider` |
| Sections | `SectionHeader`, `StatsGrid`, `TabBar`, `Hero`, `BrowserFrame`, `Footer` |

## Develop

```sh
pnpm install
pnpm dev          # Storybook at http://localhost:6006 — browse every component
pnpm build        # build the library into dist/ (lumin.es.js + lumin.css + types)
pnpm typecheck
```

## Design tokens

Tokens live in [`src/styles/tokens.css`](src/styles/tokens.css): surfaces,
borders, foregrounds, accents (amber / cyan-mcp / emerald-guest / teal-collab),
status colors, a type scale, a spacing scale, radii, shadows, and layout sizes.
Reference them as `var(--token)` — never hard-code values.

## Roadmap

Lumin starts from what the IWSDK Adventures hub already shipped. Natural next
steps toward a full product system: more form primitives (Select, Checkbox,
Switch), overlays (Dialog, Tooltip, Menu), a light theme, and publishing to
[Claude Design](https://claude.ai/design) via `/design-sync` so the design agent
builds with these real components.
